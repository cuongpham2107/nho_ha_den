-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th12 03, 2021 lúc 09:24 AM
-- Phiên bản máy phục vụ: 10.3.32-MariaDB-log
-- Phiên bản PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `cafpfypchosting_bio`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `banners`
--

CREATE TABLE `banners` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `banners`
--

INSERT INTO `banners` (`id`, `name`, `image`, `type`, `status`, `created_at`, `updated_at`) VALUES
(1, 'banner-2', 'banners/November2021/pLmXt6o1Vt8hZj4nH3BI.jpg', 'banner', 'ACTIVE', '2021-10-07 03:16:00', '2021-10-31 20:43:48'),
(2, 'Banner-1', 'banners/November2021/ykcv60V1b5d99AxuOqdl.jpg', 'banner', 'ACTIVE', '2021-10-07 03:17:00', '2021-10-31 20:43:37');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `order`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, 'Bài viết', 'bai-viet', '2021-10-05 20:45:13', '2021-11-26 21:14:09'),
(2, NULL, 1, 'Tin tức - Sự kiện', 'tin-tuc-su-kien', '2021-10-05 20:45:13', '2021-11-26 21:14:27');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `data_rows`
--

CREATE TABLE `data_rows` (
  `id` int(10) UNSIGNED NOT NULL,
  `data_type_id` int(10) UNSIGNED NOT NULL,
  `field` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `browse` tinyint(1) NOT NULL DEFAULT 1,
  `read` tinyint(1) NOT NULL DEFAULT 1,
  `edit` tinyint(1) NOT NULL DEFAULT 1,
  `add` tinyint(1) NOT NULL DEFAULT 1,
  `delete` tinyint(1) NOT NULL DEFAULT 1,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `data_rows`
--

INSERT INTO `data_rows` (`id`, `data_type_id`, `field`, `type`, `display_name`, `required`, `browse`, `read`, `edit`, `add`, `delete`, `details`, `order`) VALUES
(1, 1, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(2, 1, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(3, 1, 'email', 'text', 'Email', 1, 1, 1, 1, 1, 1, NULL, 3),
(4, 1, 'password', 'password', 'Password', 1, 0, 0, 1, 1, 0, NULL, 4),
(5, 1, 'remember_token', 'text', 'Remember Token', 0, 0, 0, 0, 0, 0, NULL, 5),
(6, 1, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, NULL, 6),
(7, 1, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 7),
(8, 1, 'avatar', 'image', 'Avatar', 0, 1, 1, 1, 1, 1, NULL, 8),
(9, 1, 'user_belongsto_role_relationship', 'relationship', 'Role', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":0}', 10),
(10, 1, 'user_belongstomany_role_relationship', 'relationship', 'voyager::seeders.data_rows.roles', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\",\"taggable\":\"0\"}', 11),
(11, 1, 'settings', 'hidden', 'Settings', 0, 0, 0, 0, 0, 0, NULL, 12),
(12, 2, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(13, 2, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(14, 2, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(15, 2, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(16, 3, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(17, 3, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(18, 3, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(19, 3, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(20, 3, 'display_name', 'text', 'Display Name', 1, 1, 1, 1, 1, 1, NULL, 5),
(21, 1, 'role_id', 'text', 'Role', 1, 1, 1, 1, 1, 1, NULL, 9),
(22, 4, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(23, 4, 'parent_id', 'select_dropdown', 'Parent', 0, 0, 1, 1, 1, 1, '{\"default\":\"\",\"null\":\"\",\"options\":{\"\":\"-- None --\"},\"relationship\":{\"key\":\"id\",\"label\":\"name\"}}', 2),
(24, 4, 'order', 'text', 'Order', 1, 1, 1, 1, 1, 1, '{\"default\":1}', 3),
(25, 4, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 4),
(26, 4, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"name\"}}', 5),
(27, 4, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, NULL, 6),
(28, 4, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 7),
(29, 5, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(30, 5, 'author_id', 'text', 'Author', 1, 0, 1, 1, 0, 1, NULL, 2),
(31, 5, 'category_id', 'text', 'Category', 1, 0, 1, 1, 1, 0, NULL, 3),
(32, 5, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, NULL, 4),
(33, 5, 'excerpt', 'text_area', 'Excerpt', 1, 0, 1, 1, 1, 1, NULL, 5),
(34, 5, 'body', 'rich_text_box', 'Body', 1, 0, 1, 1, 1, 1, NULL, 6),
(35, 5, 'image', 'image', 'Post Image', 0, 1, 1, 1, 1, 1, '{\"resize\":{\"width\":\"1000\",\"height\":\"null\"},\"quality\":\"70%\",\"upsize\":true,\"thumbnails\":[{\"name\":\"medium\",\"scale\":\"50%\"},{\"name\":\"small\",\"scale\":\"25%\"},{\"name\":\"cropped\",\"crop\":{\"width\":\"300\",\"height\":\"250\"}}]}', 7),
(36, 5, 'slug', 'text', 'Slug', 1, 0, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\",\"forceUpdate\":true},\"validation\":{\"rule\":\"unique:posts,slug\"}}', 8),
(37, 5, 'meta_description', 'text_area', 'Meta Description', 1, 0, 1, 1, 1, 1, NULL, 9),
(38, 5, 'meta_keywords', 'text_area', 'Meta Keywords', 1, 0, 1, 1, 1, 1, NULL, 10),
(39, 5, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"DRAFT\",\"options\":{\"PUBLISHED\":\"published\",\"DRAFT\":\"draft\",\"PENDING\":\"pending\"}}', 11),
(40, 5, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, NULL, 12),
(41, 5, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 13),
(42, 5, 'seo_title', 'text', 'SEO Title', 0, 1, 1, 1, 1, 1, NULL, 14),
(43, 5, 'featured', 'checkbox', 'Featured', 1, 1, 1, 1, 1, 1, NULL, 15),
(44, 6, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(45, 6, 'author_id', 'text', 'Author', 1, 0, 0, 0, 0, 0, NULL, 2),
(46, 6, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, NULL, 3),
(47, 6, 'excerpt', 'text_area', 'Excerpt', 1, 0, 1, 1, 1, 1, NULL, 4),
(48, 6, 'body', 'rich_text_box', 'Body', 1, 0, 1, 1, 1, 1, NULL, 5),
(49, 6, 'slug', 'text', 'Slug', 1, 0, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\"},\"validation\":{\"rule\":\"unique:pages,slug\"}}', 6),
(50, 6, 'meta_description', 'text', 'Meta Description', 1, 0, 1, 1, 1, 1, NULL, 7),
(51, 6, 'meta_keywords', 'text', 'Meta Keywords', 1, 0, 1, 1, 1, 1, NULL, 8),
(52, 6, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"INACTIVE\",\"options\":{\"INACTIVE\":\"INACTIVE\",\"ACTIVE\":\"ACTIVE\"}}', 9),
(53, 6, 'created_at', 'timestamp', 'Created At', 1, 1, 1, 0, 0, 0, NULL, 10),
(54, 6, 'updated_at', 'timestamp', 'Updated At', 1, 0, 0, 0, 0, 0, NULL, 11),
(55, 6, 'image', 'image', 'Page Image', 0, 1, 1, 1, 1, 1, NULL, 12),
(56, 7, 'id', 'hidden', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(57, 7, 'name', 'text', 'Tên sản phẩm', 1, 1, 1, 1, 1, 1, '{}', 2),
(58, 7, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"name\",\"forceUpdate\":true},\"validation\":{\"rule\":\"unique:products,slug\"}}', 3),
(59, 7, 'excerpt', 'text_area', 'Mô tả', 0, 0, 1, 1, 1, 1, '{}', 4),
(60, 7, 'body', 'rich_text_box', 'Nội dung', 0, 0, 1, 1, 1, 1, '{}', 5),
(61, 7, 'image', 'image', 'Ảnh', 0, 0, 1, 1, 1, 1, '{}', 6),
(62, 7, 'meta_description', 'text', 'Meta Description', 0, 0, 1, 1, 1, 1, '{}', 7),
(63, 7, 'meta_keywords', 'text', 'Meta Keywords', 0, 0, 1, 1, 1, 1, '{}', 8),
(64, 7, 'status', 'select_dropdown', 'Trạng thái', 1, 1, 1, 1, 1, 1, '{\"default\":\"ACTIVE\",\"options\":{\"INACTIVE\":\"INACTIVE\",\"ACTIVE\":\"ACTIVE\"}}', 9),
(65, 7, 'price', 'number', 'Giá', 0, 1, 1, 1, 1, 1, '{}', 10),
(66, 7, 'created_at', 'timestamp', 'Ngày tạo', 0, 1, 1, 1, 0, 1, '{}', 11),
(67, 7, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 12),
(68, 8, 'id', 'hidden', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(69, 8, 'title', 'text', 'Tiêu đề', 1, 1, 1, 1, 1, 1, '{}', 2),
(70, 8, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\"},\"validation\":{\"rule\":\"unique:staticdatas,slug\"}}', 3),
(71, 8, 'description', 'text_area', 'Mô tả', 0, 0, 1, 1, 1, 1, '{}', 4),
(72, 8, 'body', 'rich_text_box', 'Nội dung', 0, 0, 1, 1, 1, 1, '{}', 5),
(73, 8, 'image', 'image', 'Ảnh', 0, 0, 1, 1, 1, 1, '{}', 6),
(74, 8, 'meta_description', 'text', 'Meta Description', 0, 0, 1, 1, 1, 1, '{}', 7),
(75, 8, 'meta_keywords', 'text', 'Meta Keywords', 0, 0, 1, 1, 1, 1, '{}', 8),
(76, 8, 'type', 'select_dropdown', 'Loại', 0, 1, 1, 1, 1, 1, '{\"default\":\"linh-vuc-hoat-dong\",\"options\":{\"linh-vuc-hoat-dong\":\"L\\u0129nh v\\u1ef1c ho\\u1ea1t \\u0111\\u1ed9ng\",\"slide-website\":\"Slide website\"}}', 9),
(77, 8, 'status', 'select_dropdown', 'Trạng thái', 0, 1, 1, 1, 1, 1, '{\"default\":\"ACTIVE\",\"options\":{\"INACTIVE\":\"INACTIVE\",\"ACTIVE\":\"ACTIVE\"}}', 10),
(78, 8, 'created_at', 'timestamp', 'Ngày tạo', 0, 1, 1, 1, 0, 1, '{}', 11),
(79, 8, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 12),
(80, 9, 'id', 'hidden', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(81, 9, 'name', 'text', 'Tiêu đề', 0, 1, 1, 1, 1, 1, '{}', 2),
(82, 9, 'image', 'image', 'Ảnh', 0, 0, 1, 1, 1, 1, '{}', 3),
(83, 9, 'type', 'select_dropdown', 'Loại', 0, 1, 1, 1, 1, 1, '{\"default\":\"banner\",\"options\":{\"banner\":\"Banner\"}}', 4),
(84, 9, 'status', 'select_dropdown', 'Trạng thái', 0, 1, 1, 1, 1, 1, '{\"default\":\"ACTIVE\",\"options\":{\"INACTIVE\":\"INACTIVE\",\"ACTIVE\":\"ACTIVE\"}}', 5),
(85, 9, 'created_at', 'timestamp', 'Ngày tạo', 0, 1, 1, 1, 0, 1, '{}', 6),
(86, 9, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(87, 10, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(88, 10, 'name', 'text', 'Họ tên', 0, 1, 1, 1, 1, 1, '{}', 2),
(89, 10, 'email', 'text', 'Email', 0, 1, 1, 1, 1, 1, '{}', 3),
(90, 10, 'phone', 'text', 'Điện thoại', 0, 1, 1, 1, 1, 1, '{}', 4),
(91, 10, 'title', 'text', 'Tiêu đề', 0, 1, 1, 1, 1, 1, '{}', 5),
(92, 10, 'content', 'text_area', 'Nội dung', 0, 0, 1, 1, 1, 1, '{}', 6),
(93, 10, 'created_at', 'timestamp', 'Ngày nhận', 0, 1, 1, 1, 0, 1, '{}', 7),
(94, 10, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 8),
(95, 8, 'url', 'text', 'Url', 1, 1, 1, 1, 1, 1, '{}', 13);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `data_types`
--

CREATE TABLE `data_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT 0,
  `server_side` tinyint(4) NOT NULL DEFAULT 0,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `data_types`
--

INSERT INTO `data_types` (`id`, `name`, `slug`, `display_name_singular`, `display_name_plural`, `icon`, `model_name`, `policy_name`, `controller`, `description`, `generate_permissions`, `server_side`, `details`, `created_at`, `updated_at`) VALUES
(1, 'users', 'users', 'User', 'Users', 'voyager-person', 'TCG\\Voyager\\Models\\User', 'TCG\\Voyager\\Policies\\UserPolicy', 'TCG\\Voyager\\Http\\Controllers\\VoyagerUserController', '', 1, 0, NULL, '2021-10-05 20:45:12', '2021-10-05 20:45:12'),
(2, 'menus', 'menus', 'Menu', 'Menus', 'voyager-list', 'TCG\\Voyager\\Models\\Menu', NULL, '', '', 1, 0, NULL, '2021-10-05 20:45:12', '2021-10-05 20:45:12'),
(3, 'roles', 'roles', 'Role', 'Roles', 'voyager-lock', 'TCG\\Voyager\\Models\\Role', NULL, 'TCG\\Voyager\\Http\\Controllers\\VoyagerRoleController', '', 1, 0, NULL, '2021-10-05 20:45:12', '2021-10-05 20:45:12'),
(4, 'categories', 'categories', 'Category', 'Categories', 'voyager-categories', 'TCG\\Voyager\\Models\\Category', NULL, '', '', 1, 0, NULL, '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(5, 'posts', 'posts', 'Post', 'Posts', 'voyager-news', 'TCG\\Voyager\\Models\\Post', 'TCG\\Voyager\\Policies\\PostPolicy', '', '', 1, 0, NULL, '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(6, 'pages', 'pages', 'Page', 'Pages', 'voyager-file-text', 'TCG\\Voyager\\Models\\Page', NULL, '', '', 1, 0, NULL, '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(7, 'products', 'products', 'Sản phẩm', 'Danh sách sản phẩm', NULL, 'App\\Product', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}', '2021-10-07 00:35:58', '2021-10-07 00:35:58'),
(8, 'staticdatas', 'staticdatas', 'Static Data', 'Static Data', NULL, 'App\\Staticdata', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-10-07 00:56:09', '2021-11-10 03:25:41'),
(9, 'banners', 'banners', 'Banner', 'Banners', NULL, 'App\\Banner', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}', '2021-10-07 02:58:44', '2021-10-07 02:58:44'),
(10, 'feedbacks', 'feedbacks', 'Phản hồi', 'Phản hồi', NULL, 'App\\Feedback', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-10-08 01:08:58', '2021-10-08 01:14:20');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `name`, `email`, `phone`, `title`, `content`, `created_at`, `updated_at`) VALUES
(2, 'Vương Văn Huy', 'vanhuy30305@gmail.com', '0335147577', 'DỊCH VỤ', '', '2021-10-08 01:14:43', '2021-10-08 01:14:43'),
(3, 'Vương Văn Huy', 'vanhuy30305@gmail.com', '0335147577', 'Báo giá xây dựng website', 'acbcbcb', '2021-10-08 01:16:08', '2021-10-08 01:16:08'),
(4, 'cuong', 'admin@admin.com', '0984559557', 'adfasd', 'ádfasfd', '2021-11-10 01:57:02', '2021-11-10 01:57:02');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `menus`
--

INSERT INTO `menus` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2021-10-05 20:45:13', '2021-10-05 20:45:13');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `menu_items`
--

INSERT INTO `menu_items` (`id`, `menu_id`, `title`, `url`, `target`, `icon_class`, `color`, `parent_id`, `order`, `created_at`, `updated_at`, `route`, `parameters`) VALUES
(1, 1, 'Dashboard', '', '_self', 'voyager-boat', NULL, NULL, 1, '2021-10-05 20:45:13', '2021-10-05 20:45:13', 'voyager.dashboard', NULL),
(2, 1, 'Media', '', '_self', 'voyager-images', NULL, NULL, 10, '2021-10-05 20:45:13', '2021-10-10 20:01:42', 'voyager.media.index', NULL),
(3, 1, 'Tài khoản', '', '_self', 'voyager-person', '#000000', NULL, 9, '2021-10-05 20:45:13', '2021-10-10 20:01:42', 'voyager.users.index', 'null'),
(4, 1, 'Roles', '', '_self', 'voyager-lock', NULL, NULL, 11, '2021-10-05 20:45:13', '2021-10-10 20:01:42', 'voyager.roles.index', NULL),
(5, 1, 'Tools', '', '_self', 'voyager-tools', NULL, NULL, 12, '2021-10-05 20:45:13', '2021-10-10 20:01:42', NULL, NULL),
(6, 1, 'Menu Builder', '', '_self', 'voyager-list', NULL, 5, 1, '2021-10-05 20:45:13', '2021-10-06 02:18:54', 'voyager.menus.index', NULL),
(7, 1, 'Database', '', '_self', 'voyager-data', NULL, 5, 2, '2021-10-05 20:45:13', '2021-10-06 02:18:54', 'voyager.database.index', NULL),
(8, 1, 'Compass', '', '_self', 'voyager-compass', NULL, 5, 3, '2021-10-05 20:45:13', '2021-10-06 02:18:55', 'voyager.compass.index', NULL),
(9, 1, 'BREAD', '', '_self', 'voyager-bread', NULL, 5, 4, '2021-10-05 20:45:13', '2021-10-06 02:18:55', 'voyager.bread.index', NULL),
(10, 1, 'Settings', '', '_self', 'voyager-settings', NULL, NULL, 13, '2021-10-05 20:45:13', '2021-10-10 20:01:42', 'voyager.settings.index', NULL),
(11, 1, 'Danh mục bài viết', '', '_self', 'voyager-categories', '#000000', NULL, 4, '2021-10-05 20:45:13', '2021-10-07 03:00:07', 'voyager.categories.index', 'null'),
(12, 1, 'Bài viết', '', '_self', 'voyager-news', '#000000', NULL, 5, '2021-10-05 20:45:14', '2021-10-07 03:00:07', 'voyager.posts.index', 'null'),
(13, 1, 'Trang', '', '_self', 'voyager-file-text', '#000000', NULL, 3, '2021-10-05 20:45:14', '2021-10-07 03:00:07', 'voyager.pages.index', 'null'),
(14, 1, 'Sản phẩm', '', '_self', 'voyager-folder', '#000000', NULL, 6, '2021-10-07 00:35:58', '2021-10-07 03:00:07', 'voyager.products.index', 'null'),
(15, 1, 'Static Data', '', '_self', 'voyager-thumb-tack', '#000000', NULL, 7, '2021-10-07 00:56:09', '2021-10-07 03:00:07', 'voyager.staticdatas.index', 'null'),
(16, 1, 'Banners', '', '_self', 'voyager-photos', '#000000', NULL, 2, '2021-10-07 02:58:44', '2021-10-07 03:00:07', 'voyager.banners.index', 'null'),
(17, 1, 'Phản hồi', '', '_self', 'voyager-paper-plane', '#000000', NULL, 8, '2021-10-08 01:08:58', '2021-10-10 20:01:56', 'voyager.feedbacks.index', 'null');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_01_01_000000_add_voyager_user_fields', 1),
(4, '2016_01_01_000000_create_data_types_table', 1),
(5, '2016_05_19_173453_create_menu_table', 1),
(6, '2016_10_21_190000_create_roles_table', 1),
(7, '2016_10_21_190000_create_settings_table', 1),
(8, '2016_11_30_135954_create_permission_table', 1),
(9, '2016_11_30_141208_create_permission_role_table', 1),
(10, '2016_12_26_201236_data_types__add__server_side', 1),
(11, '2017_01_13_000000_add_route_to_menu_items_table', 1),
(12, '2017_01_14_005015_create_translations_table', 1),
(13, '2017_01_15_000000_make_table_name_nullable_in_permissions_table', 1),
(14, '2017_03_06_000000_add_controller_to_data_types_table', 1),
(15, '2017_04_21_000000_add_order_to_data_rows_table', 1),
(16, '2017_07_05_210000_add_policyname_to_data_types_table', 1),
(17, '2017_08_05_000000_add_group_to_settings_table', 1),
(18, '2017_11_26_013050_add_user_role_relationship', 1),
(19, '2017_11_26_015000_create_user_roles_table', 1),
(20, '2018_03_11_000000_add_user_settings', 1),
(21, '2018_03_14_000000_add_details_to_data_types_table', 1),
(22, '2018_03_16_000000_make_settings_value_nullable', 1),
(23, '2019_08_19_000000_create_failed_jobs_table', 1),
(24, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(25, '2016_01_01_000000_create_pages_table', 2),
(26, '2016_01_01_000000_create_posts_table', 2),
(27, '2016_02_15_204651_create_categories_table', 2),
(28, '2017_04_11_000000_alter_post_nullable_fields_table', 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `author_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INACTIVE',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `pages`
--

INSERT INTO `pages` (`id`, `author_id`, `title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Giới thiệu', 'CÔNG TY TNHH SẢN XUẤT & THƯƠNG MẠI BIO-ORGANIC', '<h2 style=\"box-sizing: border-box; margin: 0px; padding: 0px 0px 20px; border: 0px; outline: 0px; line-height: 1.8; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #767676; font-family: \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; text-align: center;\">C&Ocirc;NG TY TNHH SẢN XUẤT &amp; THƯƠNG MẠI BIO-ORGANIC&nbsp;</h2>\r\n<p style=\"box-sizing: border-box; margin: 0px; padding: 0px 0px 20px; border: 0px; outline: 0px; line-height: 1.8; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #767676; font-family: \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;\">Với ba thương hiệu Bio Mart, BcoSoy, BioFarm hoạt động với c&aacute;c sản phẩm lần lượt l&agrave; n&ocirc;ng sản v&ugrave;ng miền, thực phẩm nhập khẩu, tr&aacute;i c&acirc;y tươi, hạt dinh dưỡng/ cung cấp đậu phụ tươi, đậu hũ non, sữa đậu n&agrave;nh,... Cuối c&ugrave;ng l&agrave; Bio Farm cung cấp thịt lơn quế, thịt g&agrave; đặc sản, rau tươi hữu cơ v&agrave; c&aacute; tươi. C&ocirc;ng ty từ khi th&agrave;nh lập đến nay nổi tiếng l&agrave; thương hiệu đặc sản v&agrave; nhận được sự tin tưởng của kh&aacute;ch h&agrave;ng.&nbsp;</p>\r\n<p style=\"box-sizing: border-box; margin: 0px; padding: 0px 0px 20px; border: 0px; outline: 0px; line-height: 1.8; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #767676; font-family: \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif;\">Với mong muốn phục vụ cho kh&aacute;ch h&agrave;ng những sản phẩm c&oacute; chất lượng tốt nhất, c&ocirc;ng ty ch&uacute; trọng đầu tư cao v&agrave;o trang thiết bị v&agrave; c&ocirc;ng nghệ hiện đại, c&ugrave;ng với đội ngũ nh&acirc;n vi&ecirc;n c&oacute; tay nghề, kinh nghiệm đ&atilde; gi&uacute;p c&ocirc;ng ty nhận được nhiều bằng khen v&agrave; giải thưởng từ cơ quan chủ quản v&agrave; c&aacute;c hiệp hội nghề nghiệp, ti&ecirc;u biểu. Bio Organic lu&ocirc;n thỏa m&atilde;n v&agrave; c&oacute; tr&aacute;ch nhiệm với kh&aacute;ch h&agrave;ng bằng c&aacute;ch đa dạng h&oacute;a sản phẩm v&agrave; dịch vụ, đảm bảo chất lượng, an to&agrave;n vệ sinh thực phẩm với gi&aacute; cả cạnh tranh, t&ocirc;n trọng đạo đức kinh doanh v&agrave; tu&acirc;n theo luật định. Đặc biệt, Bio Organic đặt ra mục ti&ecirc;u ph&aacute;t triển v&agrave; duy tr&igrave; chỗ đứng tr&ecirc;n thị trường sản phẩm sạch, đ&aacute;p ứng tốt nhất c&aacute;c nhu cầu của kh&aacute;ch h&agrave;ng th&ocirc;ng qua việc đa dạng v&agrave; tối ưu h&oacute;a danh mục sản phẩm v&agrave; dịch vụ, củngcố v&agrave; gia tăng thị phần của tất cả c&aacute;c ng&agrave;nh h&agrave;ng.</p>', 'pages/November2021/ZxS24bcioaEb3DQDCIA1.jpg', 'about', 'Yar Meta Description', 'Keyword1, Keyword2', 'ACTIVE', '2021-10-05 20:45:14', '2021-11-15 00:52:22'),
(2, 1, 'Bài viết', 'Bài viết', '<p>B&agrave;i viết</p>', NULL, 'blog', 'Bài viết', 'Bài viết', 'ACTIVE', '2021-10-06 21:22:38', '2021-10-06 21:22:38'),
(3, 1, 'Liên hệ', 'Liên hệ', '<p>Li&ecirc;n hệ</p>', NULL, 'contact', 'liên hệ', 'liên hệ', 'ACTIVE', '2021-10-06 21:45:42', '2021-10-06 21:45:42'),
(4, 1, 'About home', 'trang chủ', '<p>C&Ocirc;NG TY TNHH SẢN XUẤT &amp; THƯƠNG MẠI BIO-ORGANIC&nbsp;</p>\r\n<p>Đặc sản Th&aacute;i Nguy&ecirc;n kh&ocirc;ng chỉ c&oacute; ch&egrave; b&uacute;p T&acirc;n Cương m&agrave; c&ograve;n c&aacute;c loại b&aacute;nh tr&aacute;i mang đậm tinh hoa n&uacute;i rừng t&acirc;y Bắc. C&aacute;c m&oacute;n ăn đặc sản Th&aacute;i Nguy&ecirc;n tương đối dễ l&agrave;m v&agrave; dễ mua được tr&ecirc;n đường du lịch&nbsp; kh&aacute;m ph&aacute; Th&aacute;i Nguy&ecirc;n. V&igrave; l&iacute; do đ&oacute; m&agrave; dacsanthainguyen.com.vn ra đời v&agrave; đặt mục ti&ecirc;u, t&acirc;m huyết của m&igrave;nh để mang đến những sản phẩm đậm chất đặc sản Th&aacute;i Nguy&ecirc;n tới tận tay kh&aacute;ch h&agrave;ng. Tất cả những g&igrave; m&agrave; ch&uacute;ng t&ocirc;i cung cấp đều chuẩn nguồn gốc, chất lượng v&agrave; đầu ra theo đ&uacute;ng quy định, đảm bảo vệ sinh ATTP. Đồng thời khi m&agrave; c&ocirc;ng nghệ số ph&aacute;t triển, ch&uacute;ng t&ocirc;i lu&ocirc;n quan t&acirc;m đến nhu cầu của kh&aacute;ch h&agrave;ng. dacsanthainguyen.com.vn đều được triển khai theo c&aacute;c m&ocirc; h&igrave;nh l&agrave; b&aacute;n trực tiếp, b&aacute;n online, ship h&agrave;ng theo y&ecirc;u cầu của kh&aacute;ch.&nbsp;Hi vọng với trải nghiệm mua h&agrave;ng v&agrave; những sản phẩm đặc sản của ch&uacute;ng t&ocirc;i sẽ mang tới sự h&agrave;i l&ograve;ng cho kh&aacute;ch h&agrave;ng.</p>', 'pages/November2021/ogvhImU4ME6NXbeyDN5y.jpg', 'about-home', 'About home', 'About home', 'ACTIVE', '2021-10-07 03:30:42', '2021-11-13 03:28:08');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`) VALUES
(1, 'browse_admin', NULL, '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(2, 'browse_bread', NULL, '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(3, 'browse_database', NULL, '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(4, 'browse_media', NULL, '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(5, 'browse_compass', NULL, '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(6, 'browse_menus', 'menus', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(7, 'read_menus', 'menus', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(8, 'edit_menus', 'menus', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(9, 'add_menus', 'menus', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(10, 'delete_menus', 'menus', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(11, 'browse_roles', 'roles', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(12, 'read_roles', 'roles', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(13, 'edit_roles', 'roles', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(14, 'add_roles', 'roles', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(15, 'delete_roles', 'roles', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(16, 'browse_users', 'users', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(17, 'read_users', 'users', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(18, 'edit_users', 'users', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(19, 'add_users', 'users', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(20, 'delete_users', 'users', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(21, 'browse_settings', 'settings', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(22, 'read_settings', 'settings', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(23, 'edit_settings', 'settings', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(24, 'add_settings', 'settings', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(25, 'delete_settings', 'settings', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(26, 'browse_categories', 'categories', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(27, 'read_categories', 'categories', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(28, 'edit_categories', 'categories', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(29, 'add_categories', 'categories', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(30, 'delete_categories', 'categories', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(31, 'browse_posts', 'posts', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(32, 'read_posts', 'posts', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(33, 'edit_posts', 'posts', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(34, 'add_posts', 'posts', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(35, 'delete_posts', 'posts', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(36, 'browse_pages', 'pages', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(37, 'read_pages', 'pages', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(38, 'edit_pages', 'pages', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(39, 'add_pages', 'pages', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(40, 'delete_pages', 'pages', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(41, 'browse_products', 'products', '2021-10-07 00:35:58', '2021-10-07 00:35:58'),
(42, 'read_products', 'products', '2021-10-07 00:35:58', '2021-10-07 00:35:58'),
(43, 'edit_products', 'products', '2021-10-07 00:35:58', '2021-10-07 00:35:58'),
(44, 'add_products', 'products', '2021-10-07 00:35:58', '2021-10-07 00:35:58'),
(45, 'delete_products', 'products', '2021-10-07 00:35:58', '2021-10-07 00:35:58'),
(46, 'browse_staticdatas', 'staticdatas', '2021-10-07 00:56:09', '2021-10-07 00:56:09'),
(47, 'read_staticdatas', 'staticdatas', '2021-10-07 00:56:09', '2021-10-07 00:56:09'),
(48, 'edit_staticdatas', 'staticdatas', '2021-10-07 00:56:09', '2021-10-07 00:56:09'),
(49, 'add_staticdatas', 'staticdatas', '2021-10-07 00:56:09', '2021-10-07 00:56:09'),
(50, 'delete_staticdatas', 'staticdatas', '2021-10-07 00:56:09', '2021-10-07 00:56:09'),
(51, 'browse_banners', 'banners', '2021-10-07 02:58:44', '2021-10-07 02:58:44'),
(52, 'read_banners', 'banners', '2021-10-07 02:58:44', '2021-10-07 02:58:44'),
(53, 'edit_banners', 'banners', '2021-10-07 02:58:44', '2021-10-07 02:58:44'),
(54, 'add_banners', 'banners', '2021-10-07 02:58:44', '2021-10-07 02:58:44'),
(55, 'delete_banners', 'banners', '2021-10-07 02:58:44', '2021-10-07 02:58:44'),
(56, 'browse_feedbacks', 'feedbacks', '2021-10-08 01:08:58', '2021-10-08 01:08:58'),
(57, 'read_feedbacks', 'feedbacks', '2021-10-08 01:08:58', '2021-10-08 01:08:58'),
(58, 'edit_feedbacks', 'feedbacks', '2021-10-08 01:08:58', '2021-10-08 01:08:58'),
(59, 'add_feedbacks', 'feedbacks', '2021-10-08 01:08:58', '2021-10-08 01:08:58'),
(60, 'delete_feedbacks', 'feedbacks', '2021-10-08 01:08:58', '2021-10-08 01:08:58');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `author_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PUBLISHED','DRAFT','PENDING') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `posts`
--

INSERT INTO `posts` (`id`, `author_id`, `category_id`, `title`, `seo_title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `status`, `featured`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Những món quà ý nghĩa trao người thương 20-10', NULL, 'Quà 20/10 dù là những món đồ đắt đỏ, sang trọng hay những món quà giản đơn thì điều quan trọng nhất chính là cách bạn trao chúng đến những người mình yêu thương.', '<p><strong>Qu&agrave; 20/10 d&ugrave; l&agrave; những m&oacute;n đồ đắt đỏ, sang trọng hay những m&oacute;n qu&agrave; giản đơn th&igrave; điều quan trọng nhất ch&iacute;nh l&agrave; c&aacute;ch bạn trao ch&uacute;ng đến những người m&igrave;nh y&ecirc;u thương.</strong></p>\r\n<p>C&oacute; v&ocirc; v&agrave;n gợi &yacute; cho những m&oacute;n qu&agrave; 20/10 đến mẹ/vợ/bạn g&aacute;i/thầy c&ocirc;/sếp/đối t&aacute;c. Mỗi đối tượng sẽ c&oacute; những m&oacute;n qu&agrave; tặng kh&aacute;c nhau. Bạn cần tinh tế để c&oacute; thể lựa chọn đồ ph&ugrave; hợp cho những người phụ nữ th&acirc;n thuộc trong cuộc sống của m&igrave;nh. H&atilde;y tham khảo top 30 gợi &yacute; dưới đ&acirc;y nh&eacute;.</p>\r\n<p><strong>1. &Yacute; nghĩa ng&agrave;y 20/10</strong></p>\r\n<p>20/10 l&agrave; ng&agrave;y g&igrave;? Đ&oacute; l&agrave; ng&agrave;y đặc biệt để thể hiện t&igrave;nh cảm biết ơn, y&ecirc;u thương v&agrave; tri &acirc;n đến những người phụ nữ Việt Nam. V&agrave;o ng&agrave;y n&agrave;y năm 1930, Hội Phụ nữ phản đế Việt Nam (sau đổi t&ecirc;n th&agrave;nh Hội Li&ecirc;n hiệp Phụ nữ) được th&agrave;nh lập. Đảng Cộng sản đ&atilde; quyết định chọn ng&agrave;y 20 th&aacute;ng 10 hằng năm để kỷ niệm v&agrave; t&ocirc;n vinh phụ nữ Việt lấy t&ecirc;n l&agrave; ng&agrave;y Phụ nữ Việt Nam.&nbsp;</p>\r\n<p>Phụ nữ Việt Nam với nhiều đức t&iacute;nh hiền l&agrave;nh, chăm chỉ, đảm đang, giữ vai tr&ograve; quan trọng trong việc g&igrave;n giữ v&agrave; ph&aacute;t triển bản sắc văn h&oacute;a d&acirc;n tộc. Ng&agrave;y nay, phụ nữ Việt vẫn lu&ocirc;n giữ được n&eacute;t đẹp ấy. Ch&iacute;nh v&igrave; thế m&agrave; ng&agrave;y 20/10 được coi l&agrave; ng&agrave;y để ch&uacute;ng ta t&ocirc;n vinh những người phụ nữ Việt Nam.&nbsp;</p>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/11.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Ng&agrave;y 20/10 h&agrave;ng năm l&agrave; ng&agrave;y t&ocirc;n vinh phụ nữ Việt (Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"e10e09dc-035c-40f7-87ed-b16fa8308359\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Ng&agrave;y 20/10 h&agrave;ng năm l&agrave; ng&agrave;y t&ocirc;n vinh phụ nữ Việt (Ảnh: Sưu tầm)</em></p>\r\n<p><strong>2. Qu&agrave; tặng 20/10 d&agrave;nh cho những ai?</strong></p>\r\n<p><em>2.1. Tặng mẹ/mẹ chồng</em></p>\r\n<p>Mẹ l&agrave; người v&ocirc; c&ugrave;ng quan trọng trong cuộc đời mỗi ch&uacute;ng ta. V&igrave; vậy h&atilde;y d&agrave;nh những m&oacute;n qu&agrave; 20/10 tốt đẹp nhất để b&agrave;y tỏ l&ograve;ng biết ơn đến mẹ của m&igrave;nh.&nbsp;</p>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/2.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Tặng m&oacute;n qu&agrave; 20/10 cho mẹ để cảm ơn những hy sinh m&agrave; họ lu&ocirc;n d&agrave;nh cho ch&uacute;ng ta&lt;br /&gt;\r\n(Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"c40c61d8-aa6a-49b0-809b-b616a9d80ed8\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Tặng m&oacute;n qu&agrave; 20/10 cho mẹ để cảm ơn những hy sinh m&agrave; họ lu&ocirc;n d&agrave;nh cho ch&uacute;ng ta<br style=\"box-sizing: border-box;\" />(Ảnh: Sưu tầm)</em></p>\r\n<p><em>2.2. Tặng c&ocirc; gi&aacute;o</em></p>\r\n<p>Qu&agrave; 20/10 tặng c&ocirc; gi&aacute;o l&agrave; rất cần thiết, thể hiện sự biết ơn với những ng&agrave;y th&aacute;ng d&igrave;u dắt, dạy dỗ ch&uacute;ng ta n&ecirc;n người.&nbsp;</p>\r\n<p><em>2.3. Tặng vợ</em></p>\r\n<p>Vợ vẫn lu&ocirc;n l&agrave; người chăm s&oacute;c v&agrave; hy sinh nhiều nhất cho gia đ&igrave;nh. Đ&acirc;y l&agrave; dịp để những đức &ocirc;ng chồng thể hiện t&igrave;nh y&ecirc;u v&agrave; b&agrave;y tỏ l&ograve;ng cảm ơn bằng những m&oacute;n qu&agrave; 20/10 tặng vợ.&nbsp;&nbsp;</p>\r\n<p><em>2.4. Tặng người y&ecirc;u, bạn g&aacute;i</em></p>\r\n<p>Qu&agrave; 20/10 cho người y&ecirc;u sẽ gi&uacute;p cho nửa kia của bạn cảm thấy cảm thấy được tr&acirc;n trọng v&agrave; y&ecirc;u thương hơn đấy.&nbsp;</p>\r\n<p><em>2.5. Tặng chị em g&aacute;i</em></p>\r\n<p>Chị em g&aacute;i l&agrave; những người hết sức th&acirc;n thiết trong cuộc sống v&agrave; cũng l&agrave; những người dễ tặng qu&agrave; 20/10 nhất v&igrave; bạn đ&atilde; nắm r&otilde; sở th&iacute;ch của c&ocirc; ấy trong l&ograve;ng b&agrave;n tay rồi.&nbsp;</p>\r\n<p><em>2.6. Tặng sếp, đồng nghiệp, đối t&aacute;c, nh&acirc;n vi&ecirc;n nữ</em></p>\r\n<p>C&oacute; nhiều người cần tạo mối quan hệ tốt đẹp để gi&uacute;p ch&uacute;ng ta th&agrave;nh c&ocirc;ng hơn trong c&ocirc;ng việc như đồng nghiệp, sếp v&agrave; đối t&aacute;c. Một m&oacute;n qu&agrave; 20/10 tinh tế, sang trọng vừa thể hiện sự quan t&acirc;m vừa tạo mối quan hệ gắn b&oacute;, th&acirc;n thiết.</p>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/3.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Bất kỳ phụ nữ n&agrave;o cũng xứng đ&aacute;ng nhận được qu&agrave; 20/10 (Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"5370a57b-a71e-4a0f-9436-01718424da04\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Bất kỳ phụ nữ n&agrave;o cũng xứng đ&aacute;ng nhận được qu&agrave; 20/10 (Ảnh: Sưu tầm)</em></p>\r\n<p><strong>3. Gợi &yacute; 20+ qu&agrave; 20/10 &yacute; nghĩa d&agrave;nh tặng ph&aacute;i đẹp</strong></p>\r\n<p><em>3.1. Qu&agrave; 20/10 cho mẹ/mẹ chồng</em></p>\r\n<p>Những m&oacute;n qu&agrave; 20/10 cho mẹ tuyệt vời nhất<em>:</em></p>\r\n<ul>\r\n<li>\r\n<p>Hoa: Phụ nữ n&agrave;o cũng mong nhận được những b&oacute; hoa tươi thắm trong ng&agrave;y đặc biệt n&agrave;y. Đ&acirc;y cũng l&agrave; m&oacute;n qu&agrave; 20/10 dễ lựa chọn nhất.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Khăn cho&agrave;ng: Khăn cho&agrave;ng kh&ocirc;ng chỉ c&oacute; chức năng giữ ấm cơ thể m&agrave; c&ograve;n thể hiện sự sang trọng, lịch thiệp, l&agrave; m&oacute;n qu&agrave; 20/10 ph&ugrave; hợp để d&agrave;nh tặng mẹ.</p>\r\n</li>\r\n<li>\r\n<p>Sản phẩm chăm s&oacute;c sức khỏe: Sức khỏe lu&ocirc;n l&agrave; điều quan t&acirc;m của bất cứ độ tuổi n&agrave;o, đặc biệt l&agrave; trung ni&ecirc;n. C&aacute;c m&oacute;n qu&agrave; 20/10 sức khoẻ như thực phẩm chức năng, ghế massage l&agrave; lựa chọn rất l&yacute; tưởng.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Đồ d&ugrave;ng nh&agrave; bếp: Đối với nhiều b&agrave; mẹ th&igrave; niềm y&ecirc;u th&iacute;ch vẫn l&agrave; căn bếp gọn g&agrave;ng, hiện đại. Nếu mẹ bạn y&ecirc;u th&iacute;ch l&agrave;m b&aacute;nh hoặc nấu ăn th&igrave; h&atilde;y tặng b&agrave; những m&oacute;n qu&agrave; 20/10 l&agrave; đồ bếp tiện lợi.&nbsp;</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/4.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"H&atilde;y tặng đồ d&ugrave;ng nh&agrave; bếp cho những người mẹ đảm đang của bạn (Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"bbd1f384-6e58-4adb-8eea-b179884ef6b1\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">H&atilde;y tặng đồ d&ugrave;ng nh&agrave; bếp cho những người mẹ đảm đang của bạn (Ảnh: Sưu tầm)</em></p>\r\n<p>Bữa cơm gia đ&igrave;nh: Đ&ocirc;i khi kh&ocirc;ng cần phải những m&oacute;n qu&agrave; vật chất cầu kỳ, người mẹ chỉ mong gia đ&igrave;nh c&oacute; thể qu&acirc;y quần d&ugrave;ng một bữa cơm ấm c&uacute;ng l&agrave; đủ rồi.&nbsp;</p>\r\n<p>Liệu tr&igrave;nh spa chăm s&oacute;c da: Phụ nữ ở bất k&igrave; độ tuổi n&agrave;o cũng quan t&acirc;m đến nhan sắc, đặc biệt l&agrave; l&agrave;n da của m&igrave;nh. H&atilde;y tặng mẹ bạn một liệu tr&igrave;nh l&agrave;m đẹp như một m&oacute;n qu&agrave; 20/10 để lấy lại vẻ thanh xu&acirc;n nh&eacute;.&nbsp;</p>\r\n<p>M&oacute;n qu&agrave; tinh thần v&ocirc; gi&aacute;: Đ&ocirc;i khi chỉ cần sự c&oacute; mặt của bạn c&ugrave;ng những lời ch&uacute;c ngọt ng&agrave;o đ&atilde; l&agrave; m&oacute;n qu&agrave; 20/10 lớn nhất d&agrave;nh cho mẹ rồi.&nbsp;</p>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/5.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Những m&oacute;n qu&agrave; 20/10 d&ugrave; kh&ocirc;ng mang gi&aacute; trị vật chất lớn nhưng lại rất qu&yacute; gi&aacute; với người l&agrave;m mẹ&amp;nbsp;\" data-entity-type=\"file\" data-entity-uuid=\"ac3a305d-d8e6-42f6-86ed-93e8285bc5e4\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Những m&oacute;n qu&agrave; 20/10 d&ugrave; kh&ocirc;ng mang gi&aacute; trị vật chất lớn nhưng lại rất qu&yacute; gi&aacute; với người l&agrave;m mẹ&nbsp;</em></p>\r\n<p><em>3.2. Qu&agrave; 20/10 tặng vợ/người y&ecirc;u</em></p>\r\n<p>Nếu c&ograve;n đang băn khoăn th&igrave; h&atilde;y tham khảo những m&oacute;n qu&agrave; tặng 20/10 cho vợ v&agrave; qu&agrave; tặng 20/10 cho bạn g&aacute;i b&ecirc;n dưới nh&eacute;.&nbsp;</p>\r\n<ul>\r\n<li>\r\n<p>Mỹ phẩm: Bạn c&oacute; thể lựa chọn son, đồ trang điểm hoặc c&aacute;c loại kem dưỡng da c&oacute; thương hiệu trong c&aacute;c trung t&acirc;m thương mại để đảm bảo chất lượng.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Trang sức c&oacute; gi&aacute; trị: Qu&agrave; 20/10 cho bạn g&aacute;i hoặc vợ l&agrave; bộ trang sức v&ograve;ng đeo tay hoặc d&acirc;y chuyền sẽ c&oacute; &yacute; nghĩa kỷ niệm rất lớn.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Quần &aacute;o: C&aacute;c c&ocirc; g&aacute;i rất th&iacute;ch được tặng qu&agrave; 20/10 l&agrave; quần &aacute;o. Tuy nhi&ecirc;n, bạn n&ecirc;n dẫn c&ocirc; ấy đến cửa h&agrave;ng m&agrave; họ y&ecirc;u th&iacute;ch thay v&igrave; tự đặt nh&eacute;.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>T&uacute;i x&aacute;ch hoặc v&iacute;: Tương tự như quần &aacute;o, h&atilde;y mạnh dạn hỏi m&agrave;u sắc, k&iacute;ch thước v&agrave; thương hiệu t&uacute;i x&aacute;ch c&ocirc; ấy y&ecirc;u th&iacute;ch trước khi tặng qu&agrave; 20/10 nh&eacute;.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Bữa tối l&atilde;ng mạn: Một bữa tối l&atilde;ng mạn với hoa hồng, nến v&agrave; những m&oacute;n ăn ngon cũng l&agrave; lựa chọn tuyệt vời.&nbsp;</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/6.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Một bữa tối l&atilde;ng mạn l&agrave; m&oacute;n qu&agrave; 20/10 tuyệt vời\" data-entity-type=\"file\" data-entity-uuid=\"fbe45712-c4fc-4f19-829a-a64b305da3fe\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Một bữa tối l&atilde;ng mạn l&agrave; m&oacute;n qu&agrave; 20/10 tuyệt vời</em></p>\r\n<ul>\r\n<li>\r\n<p>Đồng hồ đ&ocirc;i: Đồng hồ vừa l&agrave; m&oacute;n đồ trang sức đẹp vừa l&agrave; qu&agrave; kỉ niệm giữa hai bạn. Một m&oacute;n qu&agrave; 20/10 rất &yacute; nghĩa.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Gấu b&ocirc;ng: Con g&aacute;i rất th&iacute;ch những g&igrave; đ&aacute;ng y&ecirc;u, v&igrave; vậy lựa chọn gấu b&ocirc;ng l&agrave;m qu&agrave; 20/10 cũng khiến họ hứng th&uacute;.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Bộ cốc in h&igrave;nh ảnh &yacute; nghĩa: Một bộ cốc đ&ocirc;i c&oacute; in ảnh của hai người sẽ l&agrave; m&oacute;n qu&agrave; 20/10 rất l&atilde;ng mạn d&agrave;nh tặng nửa kia.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Đ&egrave;n ngủ: Qu&agrave; 20/10 l&agrave; một chiếc đ&egrave;n ngủ với mong muốn c&ocirc; ấy sẽ lu&ocirc;n nhớ đến m&igrave;nh mỗi l&uacute;c nghỉ ngơi cũng l&agrave; gợi &yacute; rất tuyệt đ&uacute;ng kh&ocirc;ng?</p>\r\n</li>\r\n<li>\r\n<p>Đồ ăn vặt: Bạn c&oacute; biết con g&aacute;i đều rất th&iacute;ch đồ ăn vặt kh&ocirc;ng? H&atilde;y thử tặng c&ocirc; ấy những m&oacute;n ăn hay ho nh&eacute;.&nbsp;</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/7.png\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Quần &aacute;o, t&uacute;i x&aacute;ch, thậm ch&iacute; cả đồ ăn đều l&agrave; những thứ phụ nữ rất th&iacute;ch được tặng trong ng&agrave;y 20/10 (Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"7e5bdbe5-4ed2-4b26-9602-ac16b80ec305\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Quần &aacute;o, t&uacute;i x&aacute;ch, thậm ch&iacute; cả đồ ăn đều l&agrave; những thứ phụ nữ rất th&iacute;ch được tặng trong ng&agrave;y 20/10 (Ảnh: Sưu tầm)</em></p>\r\n<ul>\r\n<li>\r\n<p>C&acirc;y cảnh để b&agrave;n: C&acirc;y cảnh để b&agrave;n c&oacute; thể l&agrave; một lựa chọn d&agrave;nh tặng c&aacute;c c&ocirc; n&agrave;ng y&ecirc;u th&iacute;ch thi&ecirc;n nhi&ecirc;n, c&acirc;y cối.</p>\r\n</li>\r\n<li>\r\n<p>Đồ trang tr&iacute;, lưu niệm: Nếu nửa kia của bạn l&agrave; người y&ecirc;u th&iacute;ch thiết kế, bạn c&oacute; thể tặng những m&oacute;n đồ trang tr&iacute; đơn giản, tinh tế.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Qu&agrave; 20/10 h&agrave;i hước: Một bộ phim h&agrave;i hay những m&oacute;n qu&agrave; 20/10 được sắp đặt g&acirc;y bất ngờ cũng sẽ khiến bạn g&aacute;i của bạn cảm thấy th&iacute;ch th&uacute; đấy.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Chiếc xe mới: Nếu bạn c&oacute; điều kiện kinh tế tốt, h&atilde;y tặng vợ/bạn g&aacute;i m&igrave;nh chiếc &ocirc; t&ocirc; của Vinfast để đảm bảo an to&agrave;n mỗi khi c&ocirc; ấy di chuyển tr&ecirc;n đường.</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/8.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Bạn c&oacute; thể tặng &ocirc; t&ocirc; để c&ocirc; ấy thuận tiện di chuyển&amp;nbsp;&amp;nbsp;\" data-entity-type=\"file\" data-entity-uuid=\"19c2c61c-e984-4ad7-a04c-9a0825a208b0\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Bạn c&oacute; thể tặng &ocirc; t&ocirc; để c&ocirc; ấy thuận tiện di chuyển&nbsp;</em></p>\r\n<ul>\r\n<li>\r\n<p>Th&uacute; cưng: Chăm s&oacute;c th&uacute; cưng cũng gi&uacute;p ch&uacute;ng ta y&ecirc;u đời, ki&ecirc;n nhẫn v&agrave; c&oacute; được l&ograve;ng bao dung. H&atilde;y thử tặng c&ocirc; ấy một em c&uacute;n hoặc b&eacute; m&egrave;o xinh xắn nh&eacute;.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Những m&oacute;n qu&agrave; handmade: Những m&oacute;n qu&agrave; 20/10 handmade lu&ocirc;n đem lại nhiều &yacute; nghĩa. Bạn c&oacute; thể tự tay l&agrave;m thiệp 20/10 c&oacute; ghi lời ch&uacute;c d&agrave;nh tặng người phụ nữ của đời m&igrave;nh nh&eacute;.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Điện thoại mới: Những chiếc điện thoại mới hoặc đồ điện tử như laptop, m&aacute;y t&iacute;nh bảng&hellip; cũng l&agrave; niềm y&ecirc;u th&iacute;ch của c&aacute;c c&ocirc; n&agrave;ng s&agrave;nh điệu.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Chuyến du lịch &yacute; nghĩa</p>\r\n</li>\r\n</ul>\r\n<p>Th&ecirc;m một m&oacute;n qu&agrave; 20/10 đặc biệt &yacute; nghĩa nữa ch&iacute;nh l&agrave; c&aacute;c chuyến du lịch tham quan, giải tr&iacute;, mua sắm tại nhiều điểm đến như Hạ Long, Huế, Ph&uacute; Quốc, Đ&agrave; Nẵng&hellip; Hiện tại, Ph&uacute; Quốc sẽ th&iacute; điểm bong b&oacute;ng du lịch, vậy n&ecirc;n bạn c&oacute; thể tặng vợ/bạn g&aacute;i m&igrave;nh chuyến du lịch Ph&uacute; Quốc, tham quan nhiều danh lam thắng cảnh, tận hưởng kh&ocirc;ng kh&iacute; trong l&agrave;nh v&agrave; nghỉ dưỡng sang trọng, tiện nghi tại Vinpearl Ph&uacute; Quốc.</p>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://statics.vinpearl.com/qua-20_10-10_1632716561.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Chuyến du lịch, nghỉ dưỡng tại Vinpearl Ph&uacute; Quốc sẽ l&agrave; m&oacute;n qu&agrave; l&yacute; tưởng cho ng&agrave;y Phụ nữ Việt Nam\" data-entity-type=\"file\" data-entity-uuid=\"70c3de62-695b-4552-9dc9-51beb9475b8b\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Chuyến du lịch, nghỉ dưỡng tại Vinpearl Ph&uacute; Quốc sẽ l&agrave; m&oacute;n qu&agrave; l&yacute; tưởng cho ng&agrave;y Phụ nữ Việt Nam</em></p>\r\n<p><em>3.3. Qu&agrave; 20/10 tặng c&ocirc; gi&aacute;o</em></p>\r\n<ul>\r\n<li>\r\n<p>Nước hoa: Đ&acirc;y l&agrave; m&oacute;n qu&agrave; 20/10 rất lịch sự, sang trọng. Nhưng bạn n&ecirc;n lựa chọn c&aacute;c m&ugrave;i nhẹ nh&agrave;ng bởi t&iacute;nh chất c&ocirc;ng việc của c&ocirc; gi&aacute;o.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>&Aacute;o d&agrave;i: Một bộ &aacute;o d&agrave;i lịch thiệp cũng l&agrave; gợi &yacute; rất tuyệt, nhưng bạn h&atilde;y t&igrave;m hiểu sở th&iacute;ch, số đo của c&ocirc; gi&aacute;o m&igrave;nh trước khi đặt may nh&eacute;.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Gi&agrave;y d&eacute;p: Một đ&ocirc;i gi&agrave;y cao g&oacute;t vừa phải, m&agrave;u nh&atilde; nhặn sẽ rất ph&ugrave; hợp với c&aacute;c nh&agrave; gi&aacute;o.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>S&aacute;ch: S&aacute;ch lu&ocirc;n l&agrave; m&oacute;n qu&agrave; &yacute; nghĩa d&agrave;nh tặng c&ocirc; gi&aacute;o bất cứ thời điểm n&agrave;o.</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/10.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Bạn c&oacute; thể lựa chọn c&aacute;c cuốn s&aacute;ch c&oacute; nội dung nh&acirc;n văn, triết l&yacute; để tặng c&aacute;c c&ocirc; gi&aacute;o của m&igrave;nh&lt;br /&gt;\r\n(Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"c5631b23-f2be-45c6-8ed8-e41daa67cd5b\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Bạn c&oacute; thể lựa chọn c&aacute;c cuốn s&aacute;ch c&oacute; nội dung nh&acirc;n văn, triết l&yacute; để tặng c&aacute;c c&ocirc; gi&aacute;o của m&igrave;nh<br style=\"box-sizing: border-box;\" />(Ảnh: Sưu tầm)</em></p>\r\n<ul>\r\n<li>\r\n<p>Sổ tay: C&ugrave;ng với s&aacute;ch th&igrave; sổ tay cũng rất cần thiết với người thường xuy&ecirc;n phải ghi ch&eacute;p như c&aacute;c c&ocirc; gi&aacute;o.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>T&uacute;i x&aacute;ch ph&ugrave; hợp đi dạy học: Một chiếc t&uacute;i x&aacute;ch tay rộng r&atilde;i, để vừa tập A4 sẽ l&agrave; m&oacute;n qu&agrave; 20/10 tuyệt vời cho c&aacute;c c&ocirc; gi&aacute;o của ch&uacute;ng ta.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>B&uacute;t cao cấp: Một chiếc b&uacute;t sang trọng, cao cấp sẽ hỗ trợ c&ocirc; gi&aacute;o rất nhiều trong c&ocirc;ng việc. Đ&acirc;y l&agrave; m&oacute;n qu&agrave; tặng 20 10 cho c&ocirc; gi&aacute;o kh&aacute; l&yacute; tưởng.</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/111.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Một chiếc b&uacute;t cao cấp l&agrave;m qu&agrave; 20/10 chắc chắn sẽ khiến c&ocirc; gi&aacute;o bạn rất vui (Ảnh: Sưu tầm)&amp;nbsp;\" data-entity-type=\"file\" data-entity-uuid=\"fbb113de-b02e-44a7-96c9-4707fbf22d41\" /></p>\r\n<p style=\"text-align: center;\"><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; margin-bottom: 15px; margin-top: 5px; color: #413c3c; display: inline !important;\">Một chiếc b&uacute;t cao cấp l&agrave;m qu&agrave; 20/10 chắc chắn sẽ khiến c&ocirc; gi&aacute;o bạn rất vui (Ảnh: Sưu tầm)</em>&nbsp;</p>\r\n<p><em>3.4. Qu&agrave; 20/10 tặng chị em g&aacute;i</em></p>\r\n<ul>\r\n<li>\r\n<p>Gấu b&ocirc;ng: Gấu b&ocirc;ng l&agrave; m&oacute;n qu&agrave; 20/10 tặng em g&aacute;i vừa kinh tế vừa thể hiện sự quan t&acirc;m.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Mỹ phẩm: Bạn c&oacute; thể tặng em g&aacute;i m&igrave;nh những m&oacute;n đồ dưỡng da như kem dưỡng ẩm, chăm s&oacute;c t&oacute;c, chăm s&oacute;c da mặt&hellip;</p>\r\n</li>\r\n<li>\r\n<p>Phụ kiện thời trang: Đ&ocirc;i khi những chiếc khuy&ecirc;n tai xinh xắn, chiếc kẹp t&oacute;c nhiều m&agrave;u sắc cũng khiến em g&aacute;i bạn hạnh ph&uacute;c bất ngờ.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Quần &aacute;o: Con g&aacute;i ở độ tuổi n&agrave;o cũng lu&ocirc;n th&iacute;ch quần &aacute;o mới. H&atilde;y tặng em g&aacute;i m&igrave;nh những chiếc v&aacute;y xinh xắn nh&eacute;.&nbsp;</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/12.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Những phụ kiện trang sức xinh xắn, đ&aacute;ng y&ecirc;u l&agrave; m&oacute;n qu&agrave; 20/10 đầy th&uacute; vị trong mắt c&aacute;c em g&aacute;i nhỏ (Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"d7a01251-15e1-4310-a3ad-0944f95fe0b3\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Những phụ kiện trang sức xinh xắn, đ&aacute;ng y&ecirc;u l&agrave; m&oacute;n qu&agrave; 20/10 đầy th&uacute; vị trong mắt c&aacute;c em g&aacute;i nhỏ (Ảnh: Sưu tầm)</em></p>\r\n<p><em>3.5. Qu&agrave; tặng 20/10 cho nh&acirc;n vi&ecirc;n/đồng nghiệp/đối t&aacute;c/sếp nữ</em></p>\r\n<ul>\r\n<li>\r\n<p>Hoa: Hoa vốn tượng trưng cho ph&aacute;i đẹp, n&ecirc;n việc tặng những đ&oacute;a hoa tươi thắm cho đồng nghiệp, đối t&aacute;c hoặc sếp nữ l&agrave; m&oacute;n qu&agrave; 20/10 vừa tinh tế lại lịch sự, sang trọng.</p>\r\n</li>\r\n<li>\r\n<p>T&uacute;i x&aacute;ch: T&uacute;i x&aacute;ch l&agrave; m&oacute;n qu&agrave; 20/10 m&agrave; hầu hết phụ nữ đều y&ecirc;u th&iacute;ch. Tuy nhi&ecirc;n, khi tặng m&oacute;n qu&agrave; n&agrave;y cho nh&acirc;n vi&ecirc;n, đối t&aacute;c hoặc sếp, bạn n&ecirc;n t&igrave;m hiểu trước về sở th&iacute;ch, m&agrave;u sắc v&agrave; thương hiệu y&ecirc;u th&iacute;ch của đối phương để tr&aacute;nh rơi v&agrave;o t&igrave;nh trạng kh&oacute; xử.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Nước hoa: Nước hoa l&agrave; m&oacute;n qu&agrave; 20/10 rất sang trọng, ph&ugrave; hợp tặng c&aacute;c đối t&aacute;c nữ hoặc sếp nữ.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Mỹ phẩm: Bạn cũng c&oacute; thể tặng mỹ phẩm cho nh&acirc;n vi&ecirc;n, đồng nghiệp nữ hoặc đối t&aacute;c nữ. Mỹ phẩm c&oacute; thể l&agrave; mặt nạ giấy hoặc những lọ kem tay nhỏ xinh.</p>\r\n</li>\r\n<li>\r\n<p>Đồ lưu niệm: Qu&agrave; tặng 20/10 cho nh&acirc;n vi&ecirc;n bạn c&oacute; thể lựa chọn c&aacute;c m&oacute;n đồ lưu niệm như th&uacute; b&ocirc;ng, m&oacute;c ch&igrave;a kh&oacute;a, khung ảnh&hellip;</p>\r\n</li>\r\n</ul>\r\n<p><img style=\"box-sizing: border-box; font-family: montserrat; border: 0px none; vertical-align: middle; max-width: 100%; height: auto; width: 100%; color: #413c3c;\" src=\"https://bio-organic.com.vn/storage/posts/November2021/131.jpg\" alt=\"qu&agrave; 20/10\" data-align=\"center\" data-caption=\"Nước hoa, mỹ phẩm&hellip; l&agrave; những m&oacute;n đồ sang trọng, c&oacute; thể d&ugrave;ng tặng sếp nữ hoặc đối t&aacute;c&lt;br /&gt;\r\n(Ảnh: Sưu tầm)\" data-entity-type=\"file\" data-entity-uuid=\"e852488e-9b6a-49e6-843b-d799f46798bf\" /><em class=\"img_caption\" style=\"box-sizing: border-box; font-family: montserrat; text-align: center; display: block; margin-bottom: 15px; margin-top: 5px; color: #413c3c;\">Nước hoa, mỹ phẩm&hellip; l&agrave; những m&oacute;n đồ sang trọng, c&oacute; thể d&ugrave;ng tặng sếp nữ hoặc đối t&aacute;c<br style=\"box-sizing: border-box;\" />(Ảnh: Sưu tầm)</em></p>\r\n<p><strong>4. Một số lưu &yacute; khi chọn qu&agrave; 20/10</strong></p>\r\n<ul>\r\n<li>\r\n<p>Gi&aacute; trị m&oacute;n qu&agrave; hợp l&yacute;: Tặng đồ qu&aacute; đắt hoặc qu&aacute; rẻ cũng khiến đối phương cảm thấy bối rối khi nhận qu&agrave; v&igrave; kh&ocirc;ng biết cần phải đ&aacute;p trả như thế n&agrave;o. Qu&agrave; tặng cho mẹ hoặc bạn g&aacute;i/vợ kh&ocirc;ng n&ecirc;n qu&aacute; ch&uacute; trọng vật chất m&agrave; cần thể hiện t&igrave;nh cảm, tấm l&ograve;ng của m&igrave;nh trong đ&oacute;.</p>\r\n</li>\r\n<li>\r\n<p>Tặng qu&agrave; đ&uacute;ng đối tượng, thời điểm ph&ugrave; hợp: Qu&agrave; tặng mẹ/vợ/bạn g&aacute;i/đồng nghiệp nữ sẽ kh&aacute;c nhau v&agrave; c&aacute;ch tặng qu&agrave; cũng sẽ kh&aacute;c. Bạn c&oacute; thể lựa chọn theo sở th&iacute;ch của họ. V&agrave; cũng đừng qu&ecirc;n tặng qu&agrave; đ&uacute;ng ng&agrave;y lễ, sớm hoặc muộn hơn sẽ g&acirc;y ra nhiều chuyện kh&oacute; xử.&nbsp;</p>\r\n</li>\r\n<li>\r\n<p>Ch&uacute; &yacute; phong tục tập qu&aacute;n v&agrave; những điều cấm kỵ: Nếu người được tặng qu&agrave; ở v&ugrave;ng miền kh&aacute;c hoặc t&ocirc;n gi&aacute;o kh&aacute;c, bạn cần lưu &yacute; một ch&uacute;t đến phong tục tập qu&aacute;n của họ để chọn m&oacute;n đồ ph&ugrave; hợp. Tr&aacute;nh tặng một số đồ mang &yacute; nghĩa kh&ocirc;ng tốt như khăn tay, đồ c&oacute; m&agrave;u đen, đồ nguy hiểm...</p>\r\n</li>\r\n<li>\r\n<p>Một trong những m&oacute;n qu&agrave; m&agrave; phần lớn phụ nữ đều y&ecirc;u th&iacute;ch l&agrave; c&aacute;c chuyến du lịch nghỉ dưỡng, giải tr&iacute;, mua sắm, vừa mang lại gi&aacute; trị tinh thần to lớn vừa thể hiện sự quan t&acirc;m của c&aacute;nh m&agrave;y r&acirc;u đến nửa kia của thế giới. Hiện tại, Vinpearl cho ra mắt thẻ Pearl Club với c&aacute;c đặc quyền ưu đ&atilde;i v&ocirc; c&ugrave;ng hấp dẫn</p>\r\n</li>\r\n</ul>\r\n<p>&nbsp;</p>', 'posts/November2021/lcNIYrFm9sDOpj5ZehvZ.jpg', 'nhung-mon-qua-y-ngh-a-trao-nguoi-thuong-20-10', 'This is the meta description', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2021-10-05 20:45:14', '2021-11-26 22:01:36'),
(2, 1, 1, 'Nõn Măng Nứa Rừng Sấy Khô', NULL, 'Măng khô là măng tươi được sơ chế rồi đem phơi khô. Nó không chỉ để tích trữ mà măng khô còn đem đến hương vị mới khác hoàn toàn với măng tươi. Nhiều người cho rằng ăn măng không có chất gì. Tuy nhiên theo nghiên cứu khoa học gần đây thì măng chứa rất nhiều dinh dưỡng có tác dụng rất tốt cho sức khỏe.', '<p><strong>Măng nứa kh&ocirc;</strong></p>\r\n<p>Măng kh&ocirc; l&agrave; măng tươi được sơ chế rồi đem phơi kh&ocirc;. N&oacute; kh&ocirc;ng chỉ để t&iacute;ch trữ m&agrave; măng kh&ocirc; c&ograve;n đem đến hương vị mới kh&aacute;c ho&agrave;n to&agrave;n với măng tươi. Nhiều người cho rằng ăn măng kh&ocirc;ng c&oacute; chất g&igrave;. Tuy nhi&ecirc;n theo nghi&ecirc;n cứu khoa học gần đ&acirc;y th&igrave; măng chứa rất nhiều dinh dưỡng c&oacute; t&aacute;c dụng rất tốt cho sức khỏe.</p>\r\n<p>Măng kh&ocirc; l&agrave; măng tươi được sơ chế rồi đem phơi kh&ocirc;. N&oacute; kh&ocirc;ng chỉ để t&iacute;ch trữ m&agrave; măng kh&ocirc; c&ograve;n đem đến hương vị mới kh&aacute;c ho&agrave;n to&agrave;n với măng tươi.</p>\r\n<p>Ở Việt Nam măng kh&ocirc; thường được d&ugrave;ng để nấu c&aacute;c m&oacute;n canh trong c&aacute;c bữa cỗ, tiệc v&agrave; kh&ocirc;ng thể thiếu v&agrave;o dịp tết của mỗi gia đ&igrave;nh.</p>\r\n<p>Theo dinh dưỡng học cổ truyền, măng vị ngọt hơi đắng, t&iacute;nh hơi h&agrave;n, c&oacute; c&ocirc;ng dụng h&oacute;a đ&agrave;m hạ kh&iacute;, thanh nhiệt trừ phiền, ti&ecirc;u thực giả độc, th&ocirc;ng lợi nhị tiện, thường được d&ugrave;ng để l&agrave;m thức ăn v&agrave; l&agrave;m thuốc cho những người bị cảm mạo phong nhiệt, ho do phế nhiệt c&oacute; nhiều đờm v&agrave;ng, ph&ugrave; thũng do vi&ecirc;m thận, do suy tim v&agrave; thiểu dưỡng, sởi v&agrave; thủy đậu ở trẻ em, sốt cao phiền kh&aacute;t, ăn uống chậm ti&ecirc;u, tiểu tiện bất lợi, đại tiện kh&ocirc;ng th&ocirc;ng&hellip;</p>\r\n<p>Măng l&agrave; mầm non của tre nứa&hellip;, được gọi bằng nhiều t&ecirc;n kh&aacute;c nhau như duẩn, mao duẩn, tr&uacute;c duẩn, tr&uacute;c nha&hellip; Đối với nhiều nước ở phương Đ&ocirc;ng, măng l&agrave; một trong những loại thực phẩm th&ocirc;ng dụng. Ở nước ta, măng cũng l&agrave; một nguy&ecirc;n liệu được d&ugrave;ng để chế biến nhiều m&oacute;n ăn được mọi người ưa th&iacute;ch. Thật kh&oacute; c&oacute; thể nghĩ rằng tr&ecirc;n m&acirc;m cỗ những ng&agrave;y Lễ Tết lại thiếu m&oacute;n canh măng.</p>\r\n<p>C&oacute; nhiều loại măng kh&aacute;c nhau: Tuỳ theo nguồn gốc c&oacute; măng tre, măng vầu, măng nứa, măng giang&hellip;; tuỳ theo h&agrave;m lượng nước chứa trong th&agrave;nh phần c&oacute; măng kh&ocirc;, măng tươi; tuỳ theo c&aacute;ch chế biến c&oacute; măng luộc, măng x&agrave;o, măng hầm, măng chua, măng ớt&hellip;</p>\r\n<p>Trước đ&acirc;y, c&oacute; quan niệm cho rằng măng l&agrave; một trong những đồ ăn v&ocirc; bổ, thậm ch&iacute; kh&ocirc;ng &iacute;t người nghĩ rằng ăn nhiều măng sẽ &ldquo;hại m&aacute;u&rdquo;. Nhưng, kỳ thực đ&acirc;y l&agrave; một trong những loại thực phẩm rất c&oacute; gi&aacute; trị, nhất l&agrave; trong thời buổi hiện nay khi người ta nhiều khi qu&aacute; ham đồ b&eacute;o bổ, tinh chế m&agrave; bỏ qu&ecirc;n c&aacute;c thực phẩm c&oacute; nhiều chất xơ.</p>\r\n<p><em>Kết quả nghi&ecirc;n cứu hiện đại cho thấy, măng c&oacute; chứa kh&aacute; nhiều th&agrave;nh phần dinh dưỡng. Theo c&aacute;c t&agrave;i liệu của Trung Quốc, cứ mỗi 100g măng c&oacute; chứa 4,1g protid (protid chứa trong măng c&oacute; tới 16 loại acid amin), 0,1g lipid, 5,7g glucid, 22mg Ca, 56mg Photpho, 0,1g Fe, 0,08mg caroten, 0,08 mg vitamin B1, 0,08mg vitamin B2, 0,6mg vitamin B3, 1,0mg vitamin C.</em></p>\r\n<p>Ngo&agrave;i ra, trong măng c&ograve;n chứa kh&aacute; nhiều Mg v&agrave; rất gi&agrave;u chất xơ. Với h&agrave;m lượng chất b&eacute;o, chất đường rất thấp v&agrave; gi&agrave;u chất xơ, măng l&agrave; loại thực phẩm c&oacute; t&aacute;c dụng th&uacute;c đẩy nhu động ruột, trợ gi&uacute;p ti&ecirc;u h&oacute;a, ph&ograve;ng chống c&oacute; hiệu quả t&igrave;nh trạng b&eacute;o ph&igrave;, vữa xơ động mạch, cao huyết &aacute;p, bệnh t&aacute;o b&oacute;n, bệnh ung thư đại tr&agrave;ng v&agrave; ung thư v&uacute;.</p>\r\n<p>Một số nghi&ecirc;n cứu gần đ&acirc;y cho thấy, với h&agrave;m lượng Mg kh&aacute; phong ph&uacute; v&agrave; một loại đường đa c&oacute; trong th&agrave;nh phần, măng c&oacute; khả năng nhất định trong việc ph&ograve;ng ung, kh&aacute;ng ung v&agrave; được coi l&agrave; một trong những thực phẩm chống ung thư.</p>\r\n<p>C&ograve;n ăn măng đ&atilde; được luộc kỹ do đ&atilde; loại hết HCN n&ecirc;n kh&ocirc;ng xảy ra ngộ độc.Nếu d&ugrave;ng dạng kh&ocirc; hay muối chua th&igrave; rất an to&agrave;n, v&igrave; acid loại bỏ gần như ho&agrave;n to&agrave;n.</p>\r\n<p>Măng c&aacute;c loại đều c&oacute; tỷ lệ chất xơ (cellulose) rất cao n&ecirc;n c&oacute; t&aacute;c dụng nhuận trường v&agrave; c&oacute; t&aacute;c dụng l&agrave;m hạ h&agrave;m lượng cholesterol trong m&aacute;u. V&igrave; vậy ở những bệnh nh&acirc;n c&oacute; h&agrave;m lượng cholesterol trong m&aacute;u cao thường ăn măng, v&igrave; đ&acirc;y cũng l&agrave; một biện ph&aacute;p giảm c&acirc;n v&agrave; hạ cholesterol hiệu quả.</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/mang-nua-1jpg.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p><strong>T&aacute;c dụng nổi bật của măng kh&ocirc;</strong></p>\r\n<ul>\r\n<li>Gi&uacute;p giảm c&acirc;n</li>\r\n</ul>\r\n<p>Măng nứa l&agrave; thực phẩm tốt nhất nếu bạn đang muốn giảm c&acirc;n. Măng rất gi&agrave;u chất xơ, gi&uacute;p thỏa m&atilde;n cơn đ&oacute;i. Măng cũng chứa lượng đường v&agrave; calo kh&ocirc;ng đ&aacute;ng kể. Với tỷ lệ carbohydrate thấp hơn so với c&aacute;c thực phẩm gi&agrave;u chất xơ kh&aacute;c, măng l&agrave;thực phẩm gi&uacute;p giảm c&acirc;n l&yacute; tưởng.</p>\r\n<ul>\r\n<li>Kiểm so&aacute;t cholesterol</li>\r\n</ul>\r\n<p>Măng nứa l&agrave;m giảm lượng cholesterol xấu nhờ chứa lượng chất b&eacute;o v&agrave; calo kh&ocirc;ng đ&aacute;ng kể, nhiều chất xơ. Chất xơ gi&uacute;p giảm lượng cholesterol xấu.</p>\r\n<ul>\r\n<li>Tốt cho tim</li>\r\n</ul>\r\n<p>Măng nhiều chất dinh dưỡng thiết yếu v&agrave; kho&aacute;ng chất như selen, kali c&oacute; lợi cho tim. Th&ecirc;m v&agrave;o đ&oacute;, với lượng carbohydrate v&agrave; đường thấp, măng trở th&agrave;nh thực phẩm l&yacute; tưởng gi&uacute;p ph&ograve;ng c&aacute;c bệnh tim mạch. Măng nứa rất gi&agrave;u chất xơ, gi&uacute;p đ&agrave;o thải cholesterol xấu ra khỏi cơ thể. Việc đ&agrave;o thải cholesterol dư thừa gi&uacute;p thanh lọc động mạch v&agrave; l&agrave;m giảm nguy cơ mắc bệnh tim.</p>\r\n<ul>\r\n<li>Chống ung thư</li>\r\n</ul>\r\n<p>Măng nứa gi&agrave;u chất chống oxy h&oacute;a, gi&uacute;p loại bỏ c&aacute;c gốc tự do v&agrave; chất phytosterol tự nhi&ecirc;n, g&oacute;p phần chống ung thư. Chất chống oxy h&oacute;a c&oacute; thể loại bỏ c&aacute;c gốc tự do g&acirc;y ung thư, trong khi phytosterol tự nhi&ecirc;n trong măng gi&uacute;p ức chế sự tăng trưởng v&agrave; đột biến của c&aacute;c khối u.</p>\r\n<ul>\r\n<li>Tăng cường miễn dịch</li>\r\n</ul>\r\n<p>Măng chứa nhiều vitamin v&agrave; kho&aacute;ng chất cần thiết cho c&aacute;c hoạt động trơn tru của cơ thể. Măng nứa gi&uacute;p n&acirc;ng cao khả năng miễn dịch. Sự hiện diện của c&aacute;c vitamin thiết yếu như vitamin A, C, E, v&agrave; B gi&uacute;p tăng cường chức năng miễn dịch.</p>\r\n<ul>\r\n<li>Chống vi&ecirc;m</li>\r\n</ul>\r\n<p>Măng cũng thể hiện đặc t&iacute;nh chống vi&ecirc;m hiệu quả. Măng l&agrave;m giảm đau, vi&ecirc;m cũng như chữa l&agrave;nh vết lo&eacute;t. Măng c&oacute; thể luộc l&ecirc;n rồi ăn hoặc &eacute;p lấy nước v&agrave; b&ocirc;i trực tiếp l&ecirc;n vết thương để giảm vi&ecirc;m.</p>\r\n<ul>\r\n<li>Tốt cho người ăn ki&ecirc;ng</li>\r\n</ul>\r\n<p>Măng chứa lượng lớn chất xơ, kh&ocirc;ng chỉ l&agrave;m giảm lượng cholesterol v&agrave; cải thiện sức khỏe tim mạch m&agrave; c&ograve;n duy tr&igrave; hoạt động của đường ruột. Tr&ecirc;n thực tế, măng l&agrave; một m&oacute;n ăn l&yacute; tưởng nếu bạn đang ăn ki&ecirc;ng để giảm c&acirc;n. Trong thời đại của lối sống &iacute;t vận động, thực phẩm gi&agrave;u chất xơ m&agrave; &iacute;t ca lo như măng l&agrave; sự lựa chọn ho&agrave;n hảo.</p>\r\n<ul>\r\n<li>Chữa c&aacute;c vấn đề h&ocirc; hấp</li>\r\n</ul>\r\n<p>Măng nứa rất hiệu quả trong chữa trị c&aacute;c vấn đề về h&ocirc; hấp v&agrave; rối loạn như kh&oacute; thở, hen suyễn, vi&ecirc;m phế quản. Do c&oacute; đặc t&iacute;nh chống vi&ecirc;m, măng cũng gi&uacute;p chữa bệnh vi&ecirc;m đường h&ocirc; hấp. Bạn c&oacute; thể luộc măng v&agrave; th&ecirc;m một ch&uacute;t mật ong để l&agrave;m long đờm một c&aacute;ch hiệu quả.</p>\r\n<ul>\r\n<li>Chữa vấn đề dạ d&agrave;y</li>\r\n</ul>\r\n<p>Măng nứa rất gi&agrave;u chất xơ, gi&uacute;p l&agrave;m mềm ph&acirc;n, chữa trị t&aacute;o b&oacute;n. Măng cũng chứa c&aacute;c chất kh&aacute;c gi&uacute;p trị c&aacute;c vấn đề đường ruột v&agrave; c&aacute;c vấn đề dạ d&agrave;y.</p>\r\n<ul>\r\n<li>Kh&aacute;ng khuẩn</li>\r\n</ul>\r\n<p>Cuối c&ugrave;ng, măng c&oacute; đặc t&iacute;nh kh&aacute;ng khuẩn v&agrave; kh&aacute;ng virus. Đặc t&iacute;nh n&agrave;y khiến măng l&agrave; một phương thuốc tuyệt vời cho c&aacute;c bệnh do vi khuẩn v&agrave; virus.</p>\r\n<p><strong>C&aacute;c b&agrave;i thuốc chữa bệnh từ măng kh&ocirc;</strong></p>\r\n<ul>\r\n<li>Chữa ho do đ&agrave;m nhiệt, lồng ngực đầy tức kh&oacute; chịu</li>\r\n</ul>\r\n<p>Măng tươi mới nh&uacute; 60g, luộc ch&iacute;n, th&aacute;i miếng rồi đem x&agrave;o với gừng tươi th&aacute;i chỉ v&agrave; dầu vừng, chế đủ gia vị, ăn n&oacute;ng.</p>\r\n<ul>\r\n<li>Chữa chứng t&aacute;o b&oacute;n do nhiệt, ph&acirc;n cứng v&agrave; kh&oacute; đi</li>\r\n</ul>\r\n<p>Măng tươi 60g, luộc ch&iacute;n, th&aacute;i miếng, đem ninh với 100g gạo tẻ th&agrave;nh ch&aacute;o, chế đủ gia vị, chia ăn v&agrave;i lần trong ng&agrave;y.</p>\r\n<ul>\r\n<li>Chữa mụn nhọt, đầu đinh</li>\r\n</ul>\r\n<p>Măng mới nh&uacute; ra khỏi mặt đất 20g, bồ c&ocirc;ng anh 10g, gừng tươi 5g, tất cả rửa sạch, th&aacute;i vụn, sắc với 2 b&aacute;t nước lấy 1 b&aacute;t, chia uống 2 lần trong ng&agrave;y.</p>\r\n<ul>\r\n<li>Chữa ho do phong nhiệt</li>\r\n</ul>\r\n<p>Măng tre 20g, chua me đất 20g, rễ d&acirc;u (cạo vỏ, tẩm mật, sao v&agrave;ng) 10g, gừng tươi 8g. Tất cả rửa sạch, gi&atilde; n&aacute;t, th&ecirc;m một ch&uacute;t đường hoặc mật ong, hấp cơm rồi cho uống.</p>\r\n<ul>\r\n<li>Chữa hen phế quản</li>\r\n</ul>\r\n<p>Măng tre 40g, ốc s&ecirc;n 2 con (loại c&oacute; vỏ to, m&agrave;u v&agrave;ng n&acirc;u, miệng kh&ocirc;ng c&oacute; vảy); ốc đem đập vỏ, bỏ nội tạng chỉ lấy thịt, s&aacute;t với ph&egrave;n chua, rửa sạch cho hết nhớt, nướng v&agrave;ng, cho v&agrave;o nồi đun lấy nước đặc ; măng tre gi&atilde; n&aacute;t &eacute;p lấy nước rồi h&ograve;a với nước ốc cho uống, d&ugrave;ng li&ecirc;n tục cho đến khi bệnh ổn định.</p>\r\n<ul>\r\n<li>Chữa sởi, thủy đậu giai đoạn đầu ở trẻ em, t&aacute;o b&oacute;n ở người lớn</li>\r\n</ul>\r\n<p>Măng tươi, c&aacute; diếc, gừng tươi, hạt ti&ecirc;u lượng vừa đủ v&agrave; một ch&uacute;t rượu vang. C&aacute; diếc l&agrave;m sạch, măng rửa sạch th&aacute;i miếng, gừng tươi th&aacute;i chỉ, tất cả cho v&agrave;o nồi đun ch&iacute;n, chế th&ecirc;m gia vị, chia ăn v&agrave;i lần.</p>\r\n<ul>\r\n<li>Bồi bổ sức khỏe</li>\r\n</ul>\r\n<p>Măng kh&ocirc; 50g, hải s&acirc;m 150g, t&ocirc;m n&otilde;n 20g, rượu vang, đường trắng v&agrave; gia vị vừa đủ. T&ocirc;m n&otilde;n ng&acirc;m trong rượu h&ograve;a với nước cho nở, hải s&acirc;m th&aacute;i nhỏ qu&acirc;n cờ, măng kh&ocirc; th&aacute;i nhỏ vụn. Đun mỡ trong nồi cho n&oacute;ng gi&agrave;, cho h&agrave;nh v&agrave; gừng đập giập v&agrave;o phi thơm, cho tiếp t&ocirc;m n&otilde;n, măng kh&ocirc;, đổ nước v&agrave;o đun s&ocirc;i, cho hải s&acirc;m v&agrave;o đun th&ecirc;m 10 ph&uacute;t, đổ dầu vừng n&oacute;ng v&agrave; h&agrave;nh đ&atilde; phi thơm l&ecirc;n l&agrave; được. L&agrave; m&oacute;n ăn rất gi&agrave;u protein v&agrave; kho&aacute;ng chất, lượng mỡ v&agrave; cholesterol thấp, được d&ugrave;ng để bồi bổ cho người gi&agrave; v&agrave; người mới ốm dậy.</p>\r\n<p><strong>C&Aacute;CH SỬ DỤNG MĂNG KH&Ocirc;</strong></p>\r\n<p>Sau khi ng&acirc;m xong, cho măng v&agrave;o rổ, để măng r&aacute;o nước th&igrave; cho v&agrave;o nồi nước v&agrave; tiếp tục đun s&ocirc;i cho đến khi măng mềm ho&agrave;n to&agrave;n. N&ecirc;n để nồi măng s&ocirc;i trong &iacute;t nhất một giờ với lửa trung b&igrave;nh. Sau đ&oacute;, tiếp tục gạn hết phần nước đ&atilde; đun, cho th&ecirc;m nước mới v&agrave; đun trong khoảng một tiếng nữa để măng mềm đều. Trong qu&aacute; tr&igrave;nh đun, nếu thấy nồi măng cạn nước, phải ch&acirc;m th&ecirc;m nước v&agrave;o sao cho măng lu&ocirc;n phải ngập trong nước.</p>\r\n<p>Khi măng đ&atilde; ch&iacute;n mềm, vớt măng ra, cho v&agrave;o rổ để r&aacute;o nước v&agrave; đợi đến khi măng nguội ho&agrave;n to&agrave;n th&igrave; x&eacute; măng th&agrave;nh từng sợi mỏng, tiếp tục rửa lại bằng nước sạch. L&uacute;c n&agrave;y, phần măng kh&ocirc; đ&atilde; sẵn s&agrave;ng cho việc chế biến c&aacute;c m&oacute;n ăn.</p>\r\n<p>Ngo&agrave;i ra, nếu kh&ocirc;ng sử dụng hết lượng măng kh&ocirc; đ&atilde; luộc ch&iacute;n, bạn c&oacute; thể cho ch&uacute;ng v&agrave;o t&uacute;i c&oacute; kh&oacute;a k&eacute;o v&agrave;o bảo quản trong tủ lạnh. Thời hạn sử dụng măng kh&ocirc; trong trường hợp n&agrave;y l&agrave; một tuần nếu để ở ngăn m&aacute;t v&agrave; khoảng hơn một th&aacute;ng nếu cho v&agrave;o ngăn đ&aacute;.</p>\r\n<p>Một số m&oacute;n ăn chế biến từ măng kh&ocirc;: Thịt kho măng kh&ocirc;, b&uacute;n măng kh&ocirc;, ch&acirc;n gi&ograve; heo nấu măng kh&ocirc;, miến g&agrave; măng kh&ocirc;&hellip;</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/mang-nua-ham-xuong-heo.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p style=\"text-align: center;\"><em>Măng hầm xương heo</em></p>\r\n<p style=\"text-align: center;\"><em><img src=\"https://bio-organic.com.vn/storage/posts/November2021/cach-xao-mang-kho-ngon.jpg\" alt=\"\" width=\"100%\" /></em></p>\r\n<p style=\"text-align: center;\"><em>Măng kh&ocirc; x&agrave;o miến</em></p>\r\n<p><em>Lưu &yacute;:</em></p>\r\n<p>&ndash; Măng kh&ocirc; c&aacute;c bạn n&ecirc;n ng&acirc;m &iacute;t nhất 4-5 tiếng cho măng nở hết để khi nấu măng sẽ nhanh mềm hơn</p>\r\n<p>&ndash; M&oacute;ng gi&ograve; bạn phải nhớ l&agrave;m sạch trước khi đem nấu</p>\r\n<p>&ndash; Khi ninh xương v&agrave; m&oacute;ng gi&ograve; bạn lưu &yacute; nếu c&oacute; bọt phải phải vớt hết bọt ra để nước canh được trong, kh&ocirc;ng bị vẩn đục v&agrave; nước d&ugrave;ng c&oacute; m&ugrave;i thơm. Nếu muốn nước d&ugrave;ng thơm hơn nữa th&igrave; bạn c&oacute; thể cho th&ecirc;m một mẩu quế nhỏ.</p>\r\n<p>&ndash; C&aacute;ch chọn m&oacute;ng gi&ograve; ngon: C&aacute;c bạn n&ecirc;n mua ch&acirc;n sau, nhỏ xương nhiều thịt, b&igrave; lại mỏng. Khi chọn m&oacute;ng gi&ograve; bạn n&ecirc;n chọn những ch&acirc;n thịt chắc khoogn b&egrave;o nh&egrave;o, nặng khảng 500-600. Bạn ch&uacute; &yacute; tr&aacute;nh mua ch&acirc;n gi&ograve; to, lợn gầy, khi nấu sẽ l&acirc;u ch&iacute;n v&agrave; thịt ăn kh&ocirc;ng.</p>\r\n<p>&ndash; C&aacute;ch chọn măng kh&ocirc; ngon: Bạn n&ecirc;n chọn mua những loại măng c&oacute; m&agrave;u v&agrave;ng hơi n&acirc;u, c&ograve;n lưu giữ m&ugrave;i hương đặc trưng l&agrave; măng mới.</p>', 'posts/November2021/xLn2wbWrJSWvDoNUhAwg.jpg', 'non-mang-nua-rung-say-kho', 'Meta Description for sample post', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2021-10-05 20:45:14', '2021-11-26 20:17:17');
INSERT INTO `posts` (`id`, `author_id`, `category_id`, `title`, `seo_title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `status`, `featured`, `created_at`, `updated_at`) VALUES
(3, 1, 1, 'Hôm nay vườn được thu lứa đầu tiên rau cải cúc non', NULL, 'Nói về rau ăn lá thì không thể nào không nhắc đến rau cải cúc – một trong những loại rau ăn lá quen thuộc. Không những chúng góp phần làm bữa ăn phong phú mà còn là nguồn cung cấp vitamin dồi dào cho cơ thể', '<p><strong>Đặc điểm rau cải c&uacute;c</strong></p>\r\n<p>Ngo&agrave;i c&aacute;i t&ecirc;n quen thuộc n&agrave;y, người ta c&ograve;n biết đến ch&uacute;ng với những t&ecirc;n gọi kh&aacute;c như rau tần &ocirc;, rau xu&acirc;n c&uacute;c, rau đồng dao hay rau c&uacute;c. Đ&acirc;y l&agrave; một trong những loại rau ăn l&aacute; c&oacute; nguồn gốc từ v&ugrave;ng Địa Trung Hải v&agrave; khu vực Đ&ocirc;ng &Aacute;.</p>\r\n<p>Đ&acirc;y l&agrave; loại c&acirc;y th&acirc;n thảo, dễ th&iacute;ch nghi với thời tiết. C&acirc;y mọc đứng với chiều cao trung b&igrave;nh từ 40 &ndash; 60cm, tuy nhi&ecirc;n vẫn c&oacute; một số c&acirc;y cao đến 1m. C&acirc;y ph&aacute;t triển c&agrave;nh nh&aacute;nh sum su&ecirc;, m&agrave;u xanh lục, mềm v&agrave; khi gi&agrave; th&acirc;n chuyển m&agrave;u n&acirc;u nhạt v&agrave; th&acirc;n trở n&ecirc;n cứng.</p>\r\n<p>L&aacute; cải c&uacute;c c&oacute; dạng chẻ l&ocirc;ng chim, mọc so le nhau với chiều d&agrave;i tầm 20cm v&agrave; bề mặt l&aacute; nhẵn nhụi. Nếu bạn để &yacute;, khi cắt hay v&ograve; l&aacute; sẽ ngửi thấy m&ugrave;i thơm hắc.</p>\r\n<p>Hoa tần &ocirc; c&oacute; m&agrave;u trắng b&ecirc;n ngo&agrave;i v&agrave; b&ecirc;n trong m&agrave;u v&agrave;ng với m&ugrave;i thơm thoang thoảng. Ch&uacute;ng mọc th&agrave;nh cụm gồm nhiều b&ocirc;ng hợp lại. Quả nhỏ, chiều d&agrave;i chỉ tầm 2 &ndash; 3mm. Th&aacute;ng 1 cho đến th&aacute;ng 3 h&agrave;ng năm l&agrave; thời điểm c&acirc;y ra hoa kết quả.</p>\r\n<p>Đ&acirc;y l&agrave; loại rau c&oacute; thể được trồng quanh năm v&agrave; được nhiều người biết đến với m&oacute;n rau cải c&uacute;c luộc, x&agrave;o, nấu canh hay ăn k&egrave;m với lẩu đều kh&aacute; ngon.</p>\r\n<p>Đặc biệt, một số người c&ograve;n trồng rau c&uacute;c tần &ocirc; n&agrave;y để lấy hoa l&agrave;m tr&agrave; uống.</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/cai-cuc-1.jpg\" alt=\"Cải c&uacute;c\" width=\"100%\" /></p>\r\n<p style=\"text-align: center;\"><span style=\"color: #777777; font-family: -apple-system, Roboto, \'helvetica neue\', Arial; font-size: 16px; font-style: italic; text-align: center;\">L&aacute; cải c&uacute;c c&oacute; dạng chẻ l&ocirc;ng chim, mọc so le nhau với chiều d&agrave;i tầm 20cm v&agrave; bề mặt l&aacute; nhẵn nhụi.</span></p>\r\n<p><strong>Cải c&uacute;c c&oacute; những t&aacute;c dụng g&igrave;?</strong></p>\r\n<p>Nhờ vị m&aacute;t, ngọt, thơm, hơi the đắng lại c&oacute; đặc t&iacute;nh kh&ocirc;ng độc n&ecirc;n trong Đ&ocirc;ng y đ&acirc;y l&agrave; một loại rau xanh c&oacute; nhiều c&ocirc;ng dụng tốt cho sức khỏe như:</p>\r\n<ul>\r\n<li>Bổ trợ cho thận, trị chứng tiểu tiện nhiều lần;</li>\r\n<li>Gi&uacute;p lưu th&ocirc;ng kh&iacute; huyết;</li>\r\n<li>Tốt cho những người thường xuy&ecirc;n mất ngủ;</li>\r\n<li>Cải c&uacute;c gi&uacute;p trị ho c&oacute; đờm;</li>\r\n<li>Gi&uacute;p hạ huyết &aacute;p, ổn định tim mạch;</li>\r\n<li>Cải thiện chứng hay bất an, hồi hộp;</li>\r\n<li>Gi&uacute;p mẹ nu&ocirc;i con nhỏ c&oacute; nhiều sữa cho b&eacute;;</li>\r\n<li>Đặc biệt l&agrave; cải thiện tr&iacute; nhớ.</li>\r\n</ul>\r\n<p>Cả trong T&acirc;y y nhiều nghi&ecirc;n cứu về th&agrave;nh phần cải c&uacute;c cũng chỉ ra những hữu dụng tương tự tr&ecirc;n. Đ&oacute; l&agrave; nhờ ch&uacute;ng chứa nhiều vitamin A, B, C, E, K v&agrave; chất b&eacute;o, đường, chất sắt, kẽm, nhiều loại axit amin quan trọng cần thiết cho hoạt động sống. Đặc biệt, ch&uacute;ng c&ograve;n chứa nhiều chất xơ, prolin, lysin, glutamic, analin, tinh dầu thơm, selen, threonin, aspartat&hellip;.</p>\r\n<p><strong>Khi d&ugrave;ng cải c&uacute;c cần lưu &yacute; những yếu tố sau</strong></p>\r\n<p>Tuy đ&acirc;y l&agrave; loại rau cải gi&agrave;u dinh dưỡng, hỗ trợ tốt cho sức khỏe cũng như g&oacute;p phần điều trị bệnh hiệu quả. Tuy nhi&ecirc;n, khi d&ugrave;ng cải c&uacute;c bạn cần lưu &yacute; những điều sau đ&acirc;y:</p>\r\n<ul>\r\n<li>Do rau c&oacute; t&iacute;nh m&aacute;t n&ecirc;n những người hay bị lạnh bụng, thể trạng hư h&agrave;n hoặc đang bị ti&ecirc;u chảy tuyệt đối kh&ocirc;ng n&ecirc;n d&ugrave;ng dưới bất kỳ h&igrave;nh thức n&agrave;o.</li>\r\n<li>Rau n&agrave;y dễ nhiễm trứng giun n&ecirc;n khi muốn ăn sống bạn cần rửa thật sạch hoặc tốt nhất l&agrave; nấu ch&iacute;n trước khi ăn. Đ&acirc;y l&agrave; l&yacute; do nhiều người thắc mắc rau cải c&uacute;c c&oacute; ăn sống được kh&ocirc;ng. Vẫn được nh&eacute;! Nhưng d&ugrave;ng với lượng vừa phải v&agrave; khi đ&atilde; vệ sinh thật sạch sẽ.</li>\r\n<li>Đối với những t&aacute;c dụng trị ho, giải cảm hay hạ huyết &aacute;p, bạn cần ki&ecirc;n tr&igrave; thực hiện li&ecirc;n tục từ 3 &ndash; 10 ng&agrave;y v&igrave; t&aacute;c dụng của ch&uacute;ng c&oacute; phần hơi chậm. Nếu những bệnh ở mức độ nghi&ecirc;m trọng, tốt nhất l&agrave; bạn n&ecirc;n theo chỉ định của b&aacute;c sỹ để chữa kịp thời.</li>\r\n</ul>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/cai-cuc-2.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p style=\"text-align: center;\"><span style=\"color: #777777; font-family: -apple-system, Roboto, \'helvetica neue\', Arial; font-size: 16px; font-style: italic; text-align: center;\">Vẫn d&ugrave;ng rau n&agrave;y để ăn sống được nhưng cần vệ sinh thật kỹ để loại bỏ trứng giun.</span></p>\r\n<p><strong>C&aacute;ch trồng cải c&uacute;c</strong></p>\r\n<p><em>Chọn thời điểm gieo trồng</em></p>\r\n<p>Bạn c&oacute; thể trồng rau n&agrave;y v&agrave;o bất kỳ thời điểm n&agrave;o trong năm v&igrave; ch&uacute;ng kh&aacute; dễ th&iacute;ch nghi với nhiều điều kiện thời tiết kh&aacute;c nhau. Tuy nhi&ecirc;n, thời điểm ph&ugrave; hợp nhất c&acirc;y cho năng suất cao nhất l&agrave; 2 vụ ch&iacute;nh l&agrave; Đ&ocirc;ng Xu&acirc;n v&agrave; Xu&acirc;n H&egrave;.</p>\r\n<ul>\r\n<li>Với vụ Đ&ocirc;ng Xu&acirc;n: bạn gieo hạt v&agrave;o khoảng th&aacute;ng 10 &ndash; 11 v&agrave; th&aacute;n 2 &ndash; 3 l&agrave; thu hoạch;</li>\r\n<li>Với vụ Xu&acirc;n H&egrave;: bạn gieo hạt v&agrave;o khoảng th&aacute;ng 4, th&aacute;ng 5 v&agrave; đến th&aacute;ng 8, th&aacute;ng 9 th&igrave; thu hoạch.</li>\r\n</ul>\r\n<p><em>Chuẩn bị dụng cụ v&agrave; đất trồng</em></p>\r\n<p>Đất trồng ph&ugrave; hợp l&agrave; đất ph&ugrave; sa, đất thịt nhẹ, đất thịt pha c&aacute;t hay đất m&ugrave;n. Nếu muốn tăng dinh dưỡng cũng như độ tơi xốp cho đất, trước khi trồng rau bạn trộn đất với ph&acirc;n hữu cơ, ph&acirc;n chuồng ủ hoai, ph&acirc;n tr&ugrave;n quế,&hellip;</p>\r\n<p>Về dụng cụ trồng, bạn c&oacute; thể d&ugrave;ng th&ugrave;ng xốp, khay chậu,&hellip; nếu như kh&ocirc;ng c&oacute; đất vườn. Chỉ cần đảm bảo đủ diện t&iacute;ch cho c&acirc;y sinh trưởng v&agrave; c&oacute; lỗ tho&aacute;t nước để kh&ocirc;ng l&agrave;m ngập &uacute;ng c&acirc;y.</p>\r\n<p><em>Chuẩn bị hạt giống cải c&uacute;c</em></p>\r\n<p>Cũng giống như nhiều loại rau cải kh&aacute;c c&ugrave;ng họ như: cải thảo, cải bẹ xanh hay cải th&igrave;a,&hellip; Cải tần &ocirc; cũng được nh&acirc;n giống bằng hạt một c&aacute;ch dễ d&agrave;ng.</p>\r\n<p>Bạn h&atilde;y lựa chọn những nơi uy t&iacute;n để mua hạt giống cải c&uacute;c chất lượng c&oacute; tỷ lệ nảy mầm cao.</p>\r\n<p><em>Tiến h&agrave;nh gieo trồng</em></p>\r\n<p>Để xử l&yacute; mầm bệnh v&agrave; k&iacute;ch th&iacute;ch hạt giống nảy mầm nhanh ch&oacute;ng hơn bạn c&oacute; thể ng&acirc;m hạt trong nước ấm pha theo tỷ lệ 2 s&ocirc;i : 3 lạnh trong khoảng 5 &ndash; 6 tiếng đồng hồ. Sau đ&oacute;, loại bỏ hạt l&eacute;p v&agrave; rửa hạt thật sạch v&agrave; để r&aacute;o nước.</p>\r\n<p>Cho đất v&agrave;o th&ugrave;ng chậu đ&atilde; chuẩn bị, san bằng mặt đất rồi gieo hạt v&agrave;o. Bạn c&oacute; thể rạch h&agrave;ng, gieo hạt theo h&agrave;ng hoặc cũng c&oacute; thể rải đều kh&ocirc;ng theo h&agrave;ng lối. Quan trọng l&agrave; gieo với mật độ vừa phải, kh&ocirc;ng gieo qu&aacute; d&agrave;y khiến c&acirc;y kh&ocirc;ng c&oacute; kh&ocirc;ng gian sinh trưởng ph&aacute;t triển khỏe mạnh.</p>\r\n<p>Gieo hạt giống cải c&uacute;c xong, bạn phủ l&ecirc;n một lớp đất mỏng rồi tưới nước nhẹ nh&agrave;ng bằng v&ograve;i phun sương để cấp ẩm cho đất. D&ugrave;ng vật chắn che phủ l&ecirc;n chậu c&acirc;y để hạn chế nắng mưa. Đến khi c&acirc;y con xuất hiện, bạn gỡ bỏ tấm đậy để rau c&oacute; &aacute;nh nắng quang hợp tạo dinh dưỡng.</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/cai-cuc-31.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p style=\"text-align: center;\"><span style=\"color: #777777; font-family: -apple-system, Roboto, \'helvetica neue\', Arial; font-size: 16px; font-style: italic; text-align: center;\">Bạn c&oacute; thể gieo hạt theo h&agrave;ng hoặc rải đều tr&ecirc;n mặt đất.</span></p>\r\n<p><strong>C&aacute;ch chăm s&oacute;c c&acirc;y cải c&uacute;c</strong></p>\r\n<p>Qu&aacute; tr&igrave;nh chăm s&oacute;c ảnh hưởng trực tiếp đến sự sinh trưởng ph&aacute;t triển cũng như năng suất rau trồng. Bạn cần lưu &yacute; những yếu tố sau:</p>\r\n<p><em>Tưới nước</em></p>\r\n<p>Mỗi ng&agrave;y bạn tưới rau từ 1 &ndash; 2 lần v&agrave;o s&aacute;ng sớm v&agrave; chiều m&aacute;t l&agrave; được. Tuyệt đối kh&ocirc;ng tưới rau v&agrave;o buổi tối tr&aacute;nh tạo m&ocirc;i trường ẩm ướt cho s&acirc;u bệnh h&igrave;nh th&agrave;nh.</p>\r\n<p><em>B&oacute;n ph&acirc;n</em></p>\r\n<p>Khi cải c&uacute;c được 1 tuần tuổi, bạn tiến h&agrave;nh b&oacute;n th&uacute;c cho rau bằng c&aacute;c loại ph&acirc;n hữu cơ, ph&acirc;n g&agrave;, ph&acirc;n b&ograve;, ph&acirc;n tr&ugrave;n quế,&hellip;</p>\r\n<p>Do rau trồng cho gia đ&igrave;nh sử dụng n&ecirc;n tốt nhất l&agrave; bạn hạn chế tối đa việc d&ugrave;ng ph&acirc;n h&oacute;a học. Nếu d&ugrave;ng đến, bạn h&atilde;y đảm bảo kỹ thuật b&oacute;n ph&acirc;n cũng như thời gian ngưng b&oacute;n trước khi thu hoạch để c&aacute;c th&agrave;nh vi&ecirc;n trong gia đ&igrave;nh kh&ocirc;ng bị ảnh hưởng xấu đến sức khỏe.</p>\r\n<p><em>L&agrave;m cỏ, nhổ tỉa v&agrave; ph&ograve;ng tr&aacute;nh s&acirc;u bệnh</em></p>\r\n<p>Nếu bạn gieo qu&aacute; d&agrave;y, c&acirc;y mọc chen ch&uacute;c nhau, dẫn đến việc thiếu &aacute;nh s&aacute;ng. Do vậy bạn n&ecirc;n nhổ tỉa c&acirc;y thưa ra. C&acirc;y cải c&uacute;c con, bạn c&oacute; thể d&ugrave;ng để trồng qua chậu kh&aacute;c hoặc nhổ ăn sống.</p>\r\n<p>Qu&aacute; tr&igrave;nh nhổ tỉa n&ecirc;n kết hợp với việc l&agrave;m sạch cỏ để chậu c&acirc;y th&ocirc;ng tho&aacute;ng hạn chế s&acirc;u bệnh tấn c&ocirc;ng. Đ&acirc;y cũng l&agrave; c&aacute;ch để hạn chế bị cỏ h&uacute;t dinh dưỡng của c&acirc;y.</p>\r\n<p><strong>Thu hoạch</strong></p>\r\n<p>Thời gian từ l&uacute;c gieo trồng cho đến khi thu hoạch chỉ mất tầm 25 &ndash; 30 ng&agrave;y.</p>\r\n<p>Bạn n&ecirc;n thu h&aacute;i cải c&uacute;c l&uacute;c ch&uacute;ng c&ograve;n non v&igrave; để gi&agrave; sẽ mất ngon m&agrave; lại giảm đi dinh dưỡng trong rau. T&ugrave;y theo sở th&iacute;ch m&agrave; bạn c&oacute; thể nhổ cả c&acirc;y hoặc chừa lại phần gốc, tiếp tục chăm s&oacute;c để thu th&ecirc;m lứa tiếp theo.</p>\r\n<p>Sau khi thu hoạch hết rau, bạn dọn sạch rễ c&acirc;y rồi b&oacute;n th&ecirc;m ph&acirc;n hữu cơ, b&oacute;n v&ocirc;i v&agrave;o, phơi ải v&agrave; tiếp tục trồng lứa kh&aacute;c hoặc trồng th&ecirc;m những loại rau mới.</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/cai-cuc-4.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p style=\"text-align: center;\"><span style=\"color: #777777; font-family: -apple-system, Roboto, \'helvetica neue\', Arial; font-size: 16px; font-style: italic; text-align: center;\">Bạn n&ecirc;n thu hoạch rau l&uacute;c chưa gi&agrave; để rau mềm, ngon v&agrave; đầy đủ dinh dưỡng nhất.</span></p>\r\n<p>Cải c&uacute;c tương đối dễ trồng, lại l&agrave; m&oacute;n rau gi&agrave;u dinh dưỡng rất tốt cho sức khỏe n&ecirc;n nếu c&oacute; thời gian v&agrave; kh&ocirc;ng gian trống bạn h&atilde;y trồng v&agrave;i chậu rau sạch cho gia đ&igrave;nh d&ugrave;ng nh&eacute;! Hy vọng những kiến thức n&agrave;y hữu &iacute;ch đối với bạn.</p>\r\n<p>Ch&uacute;c bạn v&agrave; gia đ&igrave;nh lu&ocirc;n khỏe mạnh!</p>', 'posts/November2021/bY9D1axhb4HWxFzdpqDe.jpg', 'hom-nay-vuon-duoc-thu-lua-dau-tien-rau-cai-cuc-non', 'This is the meta description', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2021-10-05 20:45:14', '2021-11-26 20:27:33'),
(4, 1, 1, 'Chôm chôm nhãn về Bio tươi rói', NULL, 'Chôm chôm là một trong những món trái cây thanh mát ngày hè không những người lớn mà cả trẻ con đều thích. Bài viết dưới đây sẽ giúp bạn chọn được loại chôm chôm ngon và bảo quản chúng như thế nào cho đúng.', '<p><strong>C&aacute;ch lựa ch&ocirc;m ch&ocirc;m ngon</strong></p>\r\n<p>Để biết ch&ocirc;m ch&ocirc;m c&oacute; tươi hay kh&ocirc;ng, bạn h&atilde;y nh&igrave;n v&agrave;o vẻ bề ngo&agrave;i của quả ch&ocirc;m ch&ocirc;m. Thay v&igrave; lựa chọn những quả c&oacute; gai m&agrave;u th&acirc;m n&acirc;u hay đen v&agrave; vỏ bị mềm, bạn <em>h&atilde;y chọn những quả c&oacute; vỏ gi&ograve;n, gai c&oacute; m&agrave;u xanh v&agrave; cứng</em> bởi đ&acirc;y mới l&agrave; những quả tươi.</p>\r\n<p>Bạn n&ecirc;n để &yacute; nơi bạn mua, <em>nếu người b&aacute;n h&agrave;ng thường xuy&ecirc;n xịt nước l&ecirc;n ch&ocirc;m ch&ocirc;m th&igrave; kh&ocirc;ng những bạn sẽ bị lố c&acirc;n m&agrave; c&ograve;n ch&ocirc;m ch&ocirc;m sẽ dễ bị &uacute;ng hơn</em>. V&agrave; chắc chắn bạn kh&ocirc;ng muốn c&oacute; ch&ocirc;m ch&ocirc;m chỉ ăn được trong v&agrave;i ng&agrave;y.</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/meo-bao-quan-chom-chom-tuoi-lau-va-giu-duoc-do-gion-ngot-202007211039069008.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p style=\"text-align: center;\"><em>Ch&ocirc;m ch&ocirc;m c&oacute; vỏ gi&ograve;n v&agrave; gai xanh thường sẽ tươi hơn</em></p>\r\n<p>Ri&ecirc;ng với ch&ocirc;m ch&ocirc;m nh&atilde;n, những quả ngon thường c&oacute; c&acirc;n nặng từ 20-30 g/quả, v&agrave; ch&uacute;ng c&oacute; h&igrave;nh tr&aacute;i cầu v&agrave; nhỏ. Bề mặt của vỏ c&oacute; c&aacute;c vết r&aacute;p, gai xung quanh th&igrave; thưa v&agrave; ngắn. Ch&ocirc;m ch&ocirc;m nh&atilde;n khi ch&iacute;n sẽ c&oacute; m&agrave;u v&agrave;ng đỏ bắt mắt.</p>\r\n<p>Điểm nổi bật của ch&ocirc;m ch&ocirc;m nh&atilde;n l&agrave; ch&uacute;ng c&oacute; thịt d&agrave;y v&agrave; gi&ograve;n, rất dễ b&oacute;c ra khỏi hạt, c&oacute; hương đặc trưng v&agrave; c&oacute; vị ngọt đậm đ&agrave;. Một mẹo khi lựa chọn ch&ocirc;m ch&ocirc;m nh&atilde;n nữa đ&oacute; l&agrave; kh&ocirc;ng n&ecirc;n chọn những tr&aacute;i c&oacute; m&agrave;u đỏ qu&aacute; bởi khi đ&oacute; c&ugrave;i sẽ dai v&agrave; kh&oacute; t&aacute;ch ra khỏi hạt. H&atilde;y chọn những tr&aacute;i c&oacute; m&agrave;u v&agrave;ng hơi xanh bởi khi n&agrave;y ch&uacute;ng vừa ch&iacute;n tới.</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/posts/November2021/meo-bao-quan-chom-chom-tuoi-lau-va-giu-duoc-do-gion-ngot-202007211040191239.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p style=\"text-align: center;\"><em>Bạn n&ecirc;n lựa chọn ch&ocirc;m ch&ocirc;m nh&atilde;n c&oacute; vỏ m&agrave;u v&agrave;ng xanh</em></p>', 'posts/November2021/pLxW3AD2YyBHCvMDLBxo.jpg', 'chom-chom-nhan-ve-bio-tuoi-roi', 'this be a meta descript', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2021-10-05 20:45:14', '2021-11-26 20:33:33');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `excerpt`, `body`, `image`, `meta_description`, `meta_keywords`, `status`, `price`, `created_at`, `updated_at`) VALUES
(3, 'Giỏ Hoa Quả', 'gio-hoa-qua', 'Giỏ Hoa Quả', '<p>Giỏ Hoa Quả</p>', 'products/November2021/kbEMeWx7GxTGlvhATWl9.jpg', 'Giỏ Hoa Quả', 'gio hoa qua', 'ACTIVE', 150000, '2021-10-31 19:48:00', '2021-10-31 19:48:40'),
(4, 'Hạt Tiêu', 'hat-tieu', '100% tiêu đen, không tạp chất, tiêu được chọn lựa kỹ, không vụn dăm, chắc hạt, cay nồng đặc trưng. Không chất bảo quản. Không độn hạt bông gòn, hạt đu đủ, hạt cà phê non. Không tẩm bùn, sỏi, bột mì để tăng trọng lượng.', '<p>C&Ocirc;NG DỤNG SẢN PHẨM</p>\r\n<p>- Ti&ecirc;u đen xay l&agrave; sản phẩm n&ocirc;ng nghiệp tuyệt vời được sử dụng trong hầu hết c&aacute;c m&oacute;n ăn của nhiều nền ẩm thực kh&aacute;c nhau, chỉ với một lượng nhỏ ti&ecirc;u thi đ&atilde; gi&uacute;p m&oacute;n ăn dậy m&ugrave;i thơm quyến rũ.</p>\r\n<p>- Đặc biệt ti&ecirc;u c&ograve;n l&agrave; b&iacute; quyết tuyệt vời để khử đi m&ugrave;i tanh cho nhiều nguy&ecirc;n liệu chế biến.</p>\r\n<p>ĐẶC ĐIỂM NỔI BẬT</p>\r\n<p>- Ti&ecirc;u đen xay Vipep l&agrave; nh&atilde;n hiệu duy nhất truy xuất được nguồn gốc từ vườn trồng cho đến nh&agrave; m&aacute;y.</p>\r\n<p>- Sản phẩm được chế biến tr&ecirc;n d&acirc;y truyền đạt ti&ecirc;u chuẩn ISO 22000 v&agrave; cam kết kh&ocirc;ng chứa dư lượng thuốc bảo vệ thực vật. Mỗi hạt ti&ecirc;u đều được người n&ocirc;ng d&acirc;n chọn lựa kỹ lưỡng nhằm mang đến sản phẩm c&oacute; chất lượng tốt nhất tới tay người sử dụng.</p>\r\n<p>- Sản phẩm đ&atilde; v&agrave; đang được xuất sang c&aacute;c thị trường như Mỹ, Nhật v&agrave; &Uacute;c.</p>\r\n<p>- Ti&ecirc;u đen xay được đ&oacute;ng g&oacute;i trong hộp bắt mắt v&agrave; kh&ocirc;ng chứa hương liệu cũng như chất bảo quản.</p>', 'products/November2021/CGf3tSkSHGLCTLNYDAus.jpg', 'Hạt Tiêu', 'hat tieu', 'ACTIVE', 150000, '2021-10-31 19:49:00', '2021-11-26 23:36:45'),
(5, 'Lạp Xưởng', 'lap-xuong', 'Lạp xưởng heo, lạp xưởng tôm Cần Giuộc (lạp xưởng nem) được làm theo phương thức truyền thống, với nguyên liệu thịt/tôm đất thượng hạng & được ướp rượu Mai Quế Lộ', '<p>Để c&oacute; m&oacute;n lạp xưởng ngon người ta phải chọn những miếng thịt nạc, tươi n&oacute;ng, đem xay rồi ướp với rượu mai quế lộ, tỏi, đường, ti&ecirc;u hột&hellip; Ri&ecirc;ng mỡ th&igrave; xắt nhỏ cỡ hạt lựu rồi ướp với đường c&ugrave;ng gia vị cho đến l&uacute;c c&oacute; độ trong th&igrave; mới đem trộn với thịt. Lạp xưởng nổi bật với ti&ecirc;u ch&iacute; kh&ocirc;ng qu&aacute; nhiều mỡ như những loại th&ocirc;ng thường, cắn một miếng c&oacute; cảm gi&aacute;c như đang cắn một miếng thịt tươi c&oacute; vị mặn mặn, ngọt ngọt h&ograve;a lẫn với m&ugrave;i ti&ecirc;u thơm lừng, cay cay.</p>\r\n<p>Lạp xưởng t&ocirc;m c&oacute; nguy&ecirc;n liệu ch&iacute;nh l&agrave; thịt con t&ocirc;m đất địa phương, theo tỷ lệ t&ocirc;m 60%, thịt v&agrave; mỡ 20% n&ecirc;n th&iacute;ch hợp với người cần khẩu phần &iacute;t b&eacute;o. Người s&agrave;nh ăn lấy lạp xưởng t&ocirc;m nướng tr&ecirc;n bếp than hay lăn (chi&ecirc;n) với nước, m&agrave; nước dừa th&igrave; c&agrave;ng ngon. Cho nước v&agrave;o xăm xắp canh lửa nhỏ rồi d&ugrave;ng đũa trở đều cho đến khi cạn nước th&igrave; chiếc lạp xưởng cũng đ&atilde; ch&iacute;n b&oacute;ng nhẫy, v&agrave;ng ruộm nh&igrave;n đ&atilde; mắt. Lạp xưởng t&ocirc;m tươi để &iacute;t ng&agrave;y cho l&ecirc;n men vừa c&oacute; hương vị như nem chua vừa c&oacute; c&aacute;i ngọt b&eacute;o của thịt nạc, ăn &iacute;t ng&aacute;n m&agrave; đưa cay cũng rất tuyệt.</p>', 'products/November2021/QWOVsYSZYvcgV8LWx0po.jpg', 'Lạp Xưởng', 'lap xuong', 'ACTIVE', 150000, '2021-10-31 19:50:00', '2021-11-26 21:01:21'),
(6, 'Nước Mắm', 'nuoc-mam', '95% tinh cốt nước mắm cá cơm Phú Quốc, 40 độ đạm \"Đậm Ngon\". 3 KHÔNG: không thêm chất bảo quản, không đường tổng hợp, không màu tổng hợp. Đã xuất khẩu thị trường Mỹ', '<p>Nhắc m&oacute;n Việt kh&ocirc;ng thể thiếu Vị Xưa - nước mắm truyền thống Ph&uacute; Quốc l&agrave;m n&ecirc;n sự kh&aacute;c biệt của m&oacute;n Việt. Vị Xưa tự h&agrave;o với nguồn nước mắm được ủ chượp bằng phương ph&aacute;p thủ c&ocirc;ng từ c&aacute; cơm tươi v&agrave; muối biển, tạo n&ecirc;n từng giọt Vị Xưa s&oacute;ng s&aacute;nh, vị ngon đậm đ&agrave; của nước mắm xưa. Nhờ vậy n&ecirc;m m&oacute;n Việt n&agrave;o cũng chuẩn, chấm m&oacute;n Việt n&agrave;o cũng ngon.&nbsp;</p>\r\n<p>Vị Xưa tự h&agrave;o kh&ocirc;ng chỉ phục vụ người ti&ecirc;u d&ugrave;ng trong nước m&agrave; c&ograve;n được b&agrave; con kiều b&agrave;o đ&oacute;n nhận v&agrave; tin d&ugrave;ng l&agrave; minh chứng cho một chất lượng Nước mắm Vị Xưa vượt trội.</p>\r\n<p><strong>NHẮC M&Oacute;N VIỆT, NHỚ VỊ XƯA</strong></p>\r\n<p>Điểm mạnh của sản phẩm:</p>\r\n<p>1. H&igrave;nh th&agrave;nh từ v&ugrave;ng biển Ph&uacute; Quốc</p>\r\n<p>Trong h&agrave;ng trăm l&agrave;ng mắm trải d&agrave;i từ Bắc đến Nam, Ph&uacute; Quốc l&agrave; nơi quy tụ những nh&agrave; th&ugrave;ng nổi tiếng bậc nhất với hơn 200 năm tuổi nghề. Tại Ph&uacute; Quốc, c&aacute; cơm than v&agrave; c&aacute; cơm sọc ti&ecirc;u l&agrave; nguy&ecirc;n liệu ch&iacute;nh l&agrave;m n&ecirc;n những giọt nước mắm đậm đ&agrave;, cao cấp.&nbsp;</p>\r\n<p>H&agrave;nh tr&igrave;nh Vị Xưa ra đời v&agrave; g&igrave;n giữ hương vị nước mắm truyền thống bắt đầu từ những ng&agrave;y th&aacute;ng l&ecirc;nh đ&ecirc;nh tr&ecirc;n biển, đ&aacute;nh bắt những mẻ c&aacute; cơm b&eacute;o tốt dồi d&agrave;o.&nbsp;</p>\r\n<p>Sau khi đ&aacute;nh bắt, c&aacute; cơm được tiến h&agrave;nh ướp muối ngay giữa biển nhằm giữ trọn vị tươi ngon của c&aacute; khi cập bến đất liền.</p>\r\n<p>Trở về đất liền, ngư d&acirc;n bắt tay ngay v&agrave;o c&ocirc;ng đoạn ủ chượp với c&ocirc;ng thức truyền thống 3 c&aacute; - 1 muối suốt 12 th&aacute;ng r&ograve;ng để cho ra những giọt nước mắm thơm ngon, đậm đ&agrave;, ngọt hậu, &aacute;nh m&agrave;u n&acirc;u c&aacute;nh gi&aacute;n thật đẹp.</p>\r\n<p>Nước mắm Vị Xưa được ủ chượp theo phương thức truyền thống tại nh&agrave; th&ugrave;ng Ph&uacute; Quốc với c&aacute;c th&ugrave;ng chượp gỗ lớn. Từ th&ugrave;ng gỗ n&agrave;y những giọt nước mắm thượng hạng được k&eacute;o r&uacute;t v&agrave; vận chuyển về nh&agrave; m&aacute;y hiện đại để chiết r&oacute;t v&agrave; đ&oacute;ng chai th&agrave;nh phẩm, cho ra những chai nước mắm Vị Xưa cao cấp 40 độ đạm.</p>\r\n<p>2. Quy tr&igrave;nh sản xuất đạt ti&ecirc;u chuẩn quốc tế ISO</p>\r\n<p>Tại nh&agrave; m&aacute;y, nước mắm nguồn được kiểm tra nghi&ecirc;m ngặt, đạt chất lượng theo ti&ecirc;u chuẩn Nước mắm Việt Nam mới được đưa v&agrave;o chiết r&oacute;t v&agrave; đ&oacute;ng chai thủy tinh tự động.&nbsp;</p>\r\n<p>Trước khi đến tay người ti&ecirc;u d&ugrave;ng, nước mắm Vị Xưa cao cấp 40 độ đạm phải được xử l&yacute; theo ti&ecirc;u chuẩn 3 kh&ocirc;ng: Kh&ocirc;ng chất bảo quản, Kh&ocirc;ng m&agrave;u tổng hợp, Kh&ocirc;ng đường tổng hợp v&agrave; được thanh tr&ugrave;ng nhằm đảm bảo an to&agrave;n.</p>\r\n<p>Vị Xưa được sản xuất trong nh&agrave; m&aacute;y đạt ti&ecirc;u chuẩn quản l&yacute; Quốc tế ISO 22000, ISO 9001, ISO 14001, ISO 45001. Cam kết đem đến cho người d&ugrave;ng d&ograve;ng sản phẩm thơm ngon, chất lượng v&agrave; an to&agrave;n nhất</p>\r\n<p>3. Hương vị đậm ngon g&acirc;y bao thương nhớ!</p>\r\n<p>Với 95% tinh cốt c&aacute; cơm Ph&uacute; Quốc, Vị Xưa giữ trọn vẹn hương vị đậm ngon 40 độ đạm của nước mắm xưa, đem lại cho người d&ugrave;ng một trải nghiệm mới v&ocirc; c&ugrave;ng đẳng cấp nhưng vẫn giữ được chất v&agrave; hồn tu&yacute; của Nước mắm xưa.&nbsp;</p>\r\n<p>Vị Xưa vừa mang hương vị đặc trưng của c&aacute; cơm Ph&uacute; Quốc, vừa l&agrave; gia vị đậm ngon tuyệt vời để n&ecirc;m chấm cho m&oacute;n ăn th&ecirc;m đậm đ&agrave;, thơm lừng v&agrave; bắt mắt.</p>\r\n<p>Mỗi bữa cơm chỉ cần c&oacute; một ch&uacute;t nước mắm Vị Xưa c&ugrave;ng ch&eacute;n cơm trắng n&oacute;ng hổi cũng đủ để ta cảm nhận được dư vị của m&oacute;n cơm nh&agrave;. Hay đơn giản l&agrave; ch&eacute;n mắm tỏi ớt dậy hương, chấm m&oacute;n n&agrave;o cũng ngon v&agrave; hấp dẫn</p>\r\n<p>Chỉ nước mắm ngon mới được tin d&ugrave;ng v&agrave; chỉ l&agrave;m bằng t&igrave;nh y&ecirc;u mới đủ sức n&iacute;u ch&acirc;n người thưởng thức. H&igrave;nh th&agrave;nh từ t&igrave;nh y&ecirc;u v&agrave; t&acirc;m huyết của những người l&agrave;m nghề truyền thống, Vị xưa xứng danh l&agrave; loại gia vị mang quốc hồn, quốc tu&yacute; của d&acirc;n tộc.</p>', 'products/November2021/12sWuvT3iwZ846Xmlf7I.jpg', 'Nước Mắm', 'nuoc mam', 'ACTIVE', 150000, '2021-10-31 19:50:00', '2021-11-26 23:51:36'),
(7, 'Muối Chấm Hải Sản', 'muoi-cham-hai-san', 'Nước chấm hải sản 300ml được đặc chế bằng những nguyên liệu sạch như ớt, nước cốt chanh và lá chanh non cộng với công thức gia truyền được chế biến thủ công nhằm kích thích vị giác khi ăn.', '<p>Với sự h&ograve;a quyện của c&aacute;c gia vị c&ugrave;ng l&aacute; chanh v&agrave; chanh tươi, đảm bảo vị tanh của hải sản ho&agrave;n to&agrave;n biến mất, bữa đại tiệc hải sản m&agrave; h&ocirc;ng c&oacute; VUA NƯỚC CHẤM th&igrave; chỉ như bức tranh đẹp m&agrave; kh&ocirc;ng c&oacute; m&agrave;u th&ocirc;i, v&ocirc; vị....</p>\r\n<p>Ăn lẩu , ăn nướng, ăn hải sản , ăn ch&acirc;n g&agrave; c&aacute;i g&igrave; cũng ngon hết trơn &yacute;. M&agrave; c&oacute; lẽ mng cũng nghe được c&acirc;u \" Trong ẩm thực Ch&acirc;u &Aacute; nước chấm chiếm đến 60% độ ngon của m&oacute;n ăn \" , n&oacute; ngang ngửa với c&aacute;c loại sauce trong ẩm thực ch&acirc;u &Acirc;u vậy, m&oacute;n ăn c&oacute; ngon tới đ&acirc;u m&agrave; nước chấm hay sốt kh&ocirc;ng đặc sắc cũng mất hết cả vị ngon ạ.</p>', 'products/November2021/BAwyMWeU2yNajf0ReBB1.jpg', 'Muối Chấm Hải Sản', 'Muối Chấm Hải Sản', 'ACTIVE', 150000, '2021-10-31 19:51:00', '2021-11-26 20:54:27'),
(8, 'Tôm Sú', 'tom-su', 'Tôm sú được nuôi tại môi trường sạch, tôm ngon dễ ăn nên được nhiều khách hàng ưa chuộng. \r\nSize : 30-35 con/kg.', '<p>T&ocirc;m s&uacute; sống được nu&ocirc;i th&acirc;m canh trong c&aacute;c hồ ở v&ugrave;ng miền t&acirc;y ở Bạc Li&ecirc;u ...T&ocirc;m nu&ocirc;i trong m&ocirc;i trường tự nhi&ecirc;n v&agrave; cho ăn thực phẩm sạch n&ecirc;n thịt t&ocirc;m rất ngọt v&agrave; săn chắc.</p>\r\n<p><img src=\"https://bio-organic.com.vn/storage/products/November2021/t&ocirc;m-s&uacute;.jpg\" alt=\"\" width=\"100%\" /></p>', 'products/November2021/cafbeiERSSzVCQUJMvpf.jpg', 'Tôm Sú', 'Tôm Sú', 'ACTIVE', 150000, '2021-10-31 19:52:00', '2021-11-26 20:52:25'),
(9, 'Đậu Phụ', 'dau-phu', 'Đậu phụ nổi tiếng với vị thơm, mát, ngậy, béo của từng lát đậu. Để làm nên những bìa đậu mềm mịn, ngậy, béo, những người thợ phải bắt đầu công việc từ sáng sớm tinh mơ mỗi ngày. Đãi đậu tương quyết định 50% thành công của mẻ đậu. Sau khi chọn và sơ chế đậu tương kỹ càng, tỉ mỉ, bước tiếp theo là chế biến cũng phải thật tinh, thật khéo, để lấy được phần cốt đậu', '<p>Sản xuất từ đỗ tương v&agrave; được thanh tr&ugrave;ng</p>\r\n<p>Ăn liền, chi&ecirc;n, hấp, thả lẩu, nấu canh hoặc chế biến t&ugrave;y th&iacute;ch</p>\r\n<p>An to&agrave;n, tiện lợi, dinh dưỡng, hợp vệ sinh</p>', 'products/November2021/ZveZ7e4ZRdUJdWY6Ygki.jpg', 'Đậu Phụ', 'Đậu Phụ', 'ACTIVE', 150000, '2021-10-31 19:54:00', '2021-11-26 23:43:25'),
(10, 'Hạt Maca', 'hat-maca', 'Hạt Macca sấy nứt size 19-21 có nguồn gốc xuất sứ từ Tây Nguyên – Việt Nam \r\nĐược tuyển chọn một cách kỹ lưỡng để hạt có độ thơm ngon và hoàn hảo nhất có thể .\r\nTất cả các hạt đều đã được sấy giòn được tách nứt thủ công sẵn .\r\nTrên mỗi hạt đều có các khe nứt để dễ dàng tách sử dụng tách bằng dụng cụ có trong mỗi hộp Macca Tây Nguyên thành phẩm.', '<p><strong>Chất Lượng Sản Phẩm</strong>:</p>\r\n<p style=\"padding-left: 40px;\">- Hạt m&agrave;u n&acirc;u v&agrave; nh&acirc;n b&ecirc;n trong hạt m&agrave;u trắng : hạt macca size 19-21 sấy nứt được bao bọc bởi một lớp vỏ n&acirc;u gỗ ph&iacute;a ngo&agrave;i hạt v&agrave; hạt đ&atilde; được l&agrave; nứt sẵn do vậy khi sử dụng ta chỉ cần d&ugrave;ng dụng cụ t&aacute;ch hạt để lấy lớp hạt nh&acirc;n m&agrave;u trắng b&ecirc;n trong hạt để sử dụng.</p>\r\n<p style=\"padding-left: 40px;\">- Hạt c&oacute; k&iacute;ch thước đường k&iacute;nh 19 &ndash; 21 mm : Nghĩa l&agrave; đường k&iacute;nh được t&iacute;nh cho mỗi hạt macca th&agrave;nh phẩm với k&iacute;ch thước hạt sẽ từ 19 mm đến 21 mm.</p>\r\n<p style=\"padding-left: 40px;\">- Sản Phẩm đ&atilde; được sấy gi&ograve;n : tất cả 100% sản phẩm macca size 19 - 21 mm đều trải qua một qu&aacute; tr&igrave;nh sấy gi&ograve;n với một thời gian k&eacute;o d&agrave;i từ 100h - 120h sấy li&ecirc;n tục khi hạt c&ograve;n độ ẩm 30% đến khi hạt sấy gi&ograve;n đạt độ ẩm 1%.</p>\r\n<p style=\"padding-left: 40px;\">- Tất cả hạt Macca trong sản phẩm đạt tỷ lệ ho&agrave;n hảo &gt; 96% : tỷ lệ tr&ecirc;n c&oacute; nghĩa l&agrave; với 100 hạt macca khi kh&aacute;ch h&agrave;ng sử dụng th&igrave; c&oacute; tr&ecirc;n 96 hạt đạt tỷ lệ ho&agrave;n hảo nhất.</p>\r\n<p style=\"padding-left: 40px;\">- M&ugrave;i vị sản phẩm ăn c&oacute; ch&uacute;t b&eacute;o nhẹ , thơm v&agrave; ch&uacute;t ngọt tự nhi&ecirc;n của hạt : Đ&acirc;y l&agrave; m&ugrave;i vị đặc trưng của hạt macca khi thu hoạc đạt độ ch&iacute;n v&agrave; khi chế biến với c&ocirc;ng nghệ ph&ugrave; hợp với với hạt để đạt th&agrave;nh phần dinh dưỡng tốt nhất.</p>\r\n<p><strong>H&igrave;nh Thức Đ&oacute;ng G&oacute;i</strong> : .</p>\r\n<p style=\"padding-left: 40px;\">- Được đ&oacute;ng t&uacute;i Pa h&uacute;t ch&acirc;n kh&ocirc;ng , v&agrave; sử dụng hộp giấy l&agrave; lớp hộp b&ecirc;n ngo&agrave;i</p>\r\n<p style=\"padding-left: 40px;\">- Trong mỗi hộp c&oacute; 01 c&aacute;i dụng cụ khui hạt&nbsp; v&agrave; 01 t&uacute;i h&uacute;t ẩm</p>\r\n<p style=\"padding-left: 40px;\">- Trọng lượng mỗi hộp l&agrave; 500g</p>\r\n<p style=\"padding-left: 40px;\">- Hạt được sấy bằng điện 100% , giảm t&aacute;c động tới m&ocirc;i trường so với những phương ph&aacute;p truyền thống</p>\r\n<p style=\"padding-left: 40px;\">- 100% Hạt nhi&ecirc;n liệu đầu v&agrave;o được tuyển chọn kỹ c&agrave;ng trước khi đưa v&agrave;o d&acirc;y truyền chế biến</p>\r\n<p style=\"padding-left: 40px;\">- Sản xuất tại Việt Nam</p>', 'products/November2021/kqNlgecyTU8Ipr74E0Ag.jpg', 'Hạt Maca', 'Hạt Maca', 'ACTIVE', 150000, '2021-10-31 19:54:00', '2021-11-26 23:48:27'),
(11, 'Nước Mắm Nguyên Chất', 'nuoc-mam-nguyen-chat', 'Kế thừa công thức 300 năm từ Làng Chài Xưa, nước mắm Tĩn là loại nước mắm rin nguyên chất được kéo rút trực tiếp từ thùng gỗ chín chậm với cá cơm than con to béo, tươi rói và muối tinh khiết. Được ủ chượp tự nhiên trong 12 tháng, để cho ra những giọt nước mắm đặc sánh, thơm ngon với hậu vị béo ngọt vô cùng tuyệt hảo. Đặc biệt, nước mắm được đựng trong tĩn gốm đậy kín, tránh tiếp xúc với ánh nắng mặt trời nên được lên men lần thứ 2, tạo nên hương vị đậm đà đặc trưng.', '<p>Được ủ chượp tự nhi&ecirc;n trong 12 th&aacute;ng, đ&ecirc;̉ cho ra những giọt nước mắm đặc sánh, thơm ngon với h&acirc;̣u vị béo ngọt v&ocirc; cùng tuy&ecirc;̣t hảo</p>\r\n<p>Đặc bi&ecirc;̣t, nước mắm được đựng trong tĩn g&ocirc;́m đ&acirc;̣y kín, tránh ti&ecirc;́p xúc với ánh nắng mặt trời n&ecirc;n được l&ecirc;n men l&acirc;̀n thứ 2, tạo n&ecirc;n hương vị đ&acirc;̣m đà đặc trưng.</p>\r\n<p>Ngoài ra, tĩn g&ocirc;́m còn được thi&ecirc;́t k&ecirc;́ với quai x&aacute;ch d&acirc;y thừng độc đ&aacute;o, vừa mang vẻ c&ocirc;̉ xưa những toát l&ecirc;n sự sang trọng, r&acirc;́t&nbsp; th&iacute;ch hợp l&agrave;m qu&agrave; biếu tặng hoặc các bu&ocirc;̉i ti&ecirc;̣c đãi kh&aacute;ch qu&yacute;.</p>\r\n<p>Th&ocirc;ng tin sản phẩm:</p>\r\n<ul>\r\n<li>Nước mắm Rin&nbsp;</li>\r\n<li>Đạm cá: 41N (Độ đạm tự nhi&ecirc;n)</li>\r\n<li>Loại chai: 500ml/ b&igrave;nh gốm</li>\r\n<li>Hạn sử dụng: 24 th&aacute;ng&nbsp;</li>\r\n</ul>', 'products/November2021/a4yCDJS5w8yopYI9KTi9.jpg', 'Nước Mắm Nguyên Chất', 'Nước Mắm Nguyên Chất', 'ACTIVE', 150000, '2021-10-31 19:55:00', '2021-11-26 20:47:42'),
(12, 'Xà Lách Đà Lạt', 'xa-lach-da-lat', 'Là một kho cung cấp chất xơ, giàu cellulose nên xà lách còn giúp ruột có thêm chút gì để… co bóp, nhờ đó giúp thoát khỏi tình trạng táo bón. Cải xà lách còn có một đặc tính “ăn tiền” khác là có thể giúp mang lại “giấc điệp” vì có chứa một chất gây ngủ là letucarium. Đối với bệnh nhân tiểu đường, xà lách là một loại thực phẩm lý tưởng vì thuộc nhóm rau cải có thành phần carbohydrate thấp hơn 3%. Xà lách còn chứa một hàm lượng đáng kể chất sắt nên là một loại thực phẩm rất tốt cho những người bị thiếu máu do thiếu sắt', '<p>X&agrave; l&aacute;ch Carol c&oacute; xoăn tr&ograve;n c&oacute; m&agrave;u xanh đậm. Khi ăn X&agrave; l&aacute;ch Carol bạn sẽ cảm nhận được vị ngon ngọt trong từng l&aacute; x&aacute; l&aacute;ch.</p>\r\n<p>Loại x&agrave; l&aacute;ch n&agrave;y rất nhiều người ưa chuộng bởi khi ăn rất gi&ograve;n v&agrave; tươi m&aacute;t. X&agrave; l&aacute;ch carol sạch ăn sẽ c&oacute; vị hơi đắng hơn b&igrave;nh thường một ch&uacute;t, nhưng khi h&ocirc; biến th&agrave;nh m&oacute;n salad dầu giấm th&igrave; m&ugrave;i vị sẽ rất tuyệt.</p>\r\n<p>X&agrave; l&aacute;ch Carol c&ograve;n hỗ trợ ti&ecirc;u h&oacute;a v&agrave; tốt cho gan, giảm nguy cơ mắc bệnh tim mạch, nhồi m&aacute;u cơ tim, ung thư, đau cột sống, thiếu m&aacute;u v&agrave; chứng mất ngủ do căng thẳng.</p>\r\n<p>D&ugrave; l&agrave; loại n&agrave;o th&igrave; x&agrave; l&aacute;ch cũng l&agrave; loại rau cải rất gi&agrave;u chất dinh dưỡng. Cứ 100 gam x&agrave; l&aacute;ch sẽ cung cấp khoảng 2,2 gam carbohydrate, 1,2 gam chất xơ, 90 gam nước, 166 microgram vitamin A, 73 microgram folate (vitamin B9). X&agrave; l&aacute;ch c&ograve;n chứa rất nhiều muối kho&aacute;ng với những nguy&ecirc;n tố kiềm, nhờ đ&oacute; gi&uacute;p cơ thể &ldquo;dọn dẹp&rdquo; m&aacute;u, gi&uacute;p tinh thần tỉnh t&aacute;o v&agrave; gi&uacute;p cơ thể tr&aacute;nh được nhiều bệnh tật.</p>\r\n<p>Nước &eacute;p x&agrave; l&aacute;ch c&ograve;n c&oacute; t&aacute;c dụng giải nhiệt. Do chứa một h&agrave;m lượng cao magnesium n&ecirc;n nước &eacute;p x&agrave; l&aacute;ch c&oacute; một năng lực si&ecirc;u ph&agrave;m trong việc hồi phục c&aacute;c m&ocirc; cơ, tăng cường chức năng n&atilde;o. Y học d&acirc;n gian phương T&acirc;y cho rằng d&ugrave;ng dịch &eacute;p x&agrave; l&aacute;ch pha với tinh dầu hoa hồng thoa v&agrave;o tr&aacute;n v&agrave; th&aacute;i dương sẽ gi&uacute;p cắt những cơn đau đầu.</p>', 'products/November2021/fH2wiurqQItJok4yiLv4.jpg', 'Xà Lách Đà Lạt', 'Xà Lách Đà Lạt', 'ACTIVE', 150000, '2021-10-31 19:56:00', '2021-11-26 20:45:04'),
(13, 'Bí Đỏ', 'bi-do', 'Bí ngô hay bí đỏ (phương ngữ Nam bộ gọi là bí rợ) là một loại cây dây thuộc chi Cucurbita, họ Bầu bí .', '<p>B&iacute; ng&ocirc; c&acirc;n nặng từ 0,45 kg trở l&ecirc;n v&agrave; c&oacute; thể nặng đến hơn 450 kg.</p>\r\n<p>B&iacute; c&oacute; h&igrave;nh cầu hoặc h&igrave;nh trụ, ch&iacute;n th&igrave; m&agrave;u v&agrave;ng cam,[5] B&ecirc;n ngo&agrave;i c&oacute; kh&iacute;a chia th&agrave;nh từng m&uacute;i. Ruột b&iacute; c&oacute; nhiều hột. Hạt dẹp, h&igrave;nh bầu dục c&oacute; chứa nhiều dầu.</p>\r\n<p>Trong c&aacute;c loại quả chứa h&agrave;m lượng dinh dưỡng cao, b&iacute; đỏ được xếp ở vị tr&iacute; đầu ti&ecirc;n. Trong b&iacute; đỏ c&oacute; chứa sắt, kali, phosphor, nước, protein thực vật, gluxit,.. c&aacute;c axit b&eacute;o linoleic, c&ugrave;ng c&aacute;c vitamin C, vitamin B1, B2, B5, B6, PP. Ăn b&iacute; đỏ rất tốt cho n&atilde;o bộ, l&agrave;m tăng cường miễn dịch, gi&uacute;p tim khỏe mạnh, mắt s&aacute;ng, cho giấc ngủ ngon hơn v&agrave; hỗ trợ cho việc chăm s&oacute;c da cũng như l&agrave;m đẹp, gi&uacute;p giảm c&acirc;n...</p>\r\n<p>Quả b&iacute; đỏ gi&agrave;u beta caroten tiền vitamin A, chứa 85 - 91% nước, chất đạm 0,8 - 2 g, chất b&eacute;o 0,1 - 0,5 g, chất bột đường 3,3 - 11 g, năng lượng 85 -170 kJ/100 g</p>', 'products/November2021/2KtooekRvxFxDPjJTKrL.jpg', 'Bí Đỏ', 'Bí Đỏ', 'ACTIVE', 150000, '2021-10-31 19:57:00', '2021-11-26 20:42:10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', '2021-10-05 20:45:13', '2021-10-05 20:45:13'),
(2, 'user', 'Normal User', '2021-10-05 20:45:13', '2021-10-05 20:45:13');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `settings`
--

INSERT INTO `settings` (`id`, `key`, `display_name`, `value`, `details`, `type`, `order`, `group`) VALUES
(1, 'site.title', 'Site Title', 'Bio', '', 'text', 1, 'Site'),
(2, 'site.description', 'Site Description', 'Bio organic', '', 'text', 2, 'Site'),
(3, 'site.logo', 'Site Logo', 'settings/October2021/tbAECK08TxczXU9QQ1tc.png', '', 'image', 3, 'Site'),
(4, 'site.google_analytics_tracking_id', 'Google Analytics Tracking ID', NULL, '', 'text', 4, 'Site'),
(5, 'admin.bg_image', 'Admin Background Image', '', '', 'image', 5, 'Admin'),
(6, 'admin.title', 'Admin Title', 'Bio', '', 'text', 1, 'Admin'),
(7, 'admin.description', 'Admin Description', 'Welcome to Bio', '', 'text', 2, 'Admin'),
(8, 'admin.loader', 'Admin Loader', '', '', 'image', 3, 'Admin'),
(9, 'admin.icon_image', 'Admin Icon Image', '', '', 'image', 4, 'Admin'),
(10, 'admin.google_analytics_client_id', 'Google Analytics Client ID (used for admin dashboard)', NULL, '', 'text', 1, 'Admin'),
(11, 'site.Image-breadcrumb', 'Image breadcrumb', 'settings\\October2021\\pVseo50SoMaojpH7M3x4.png', NULL, 'image', 6, 'Site'),
(12, 'site.map', 'Google map', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3709.9400114800005!2d105.83648081489056!3d21.588264573817934!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x313526e7883e718f%3A0x166bd8f5856f6855!2zMTY3aSDEkC4gTWluaCBD4bqndSwgUGhhbiDEkMOsbmggUGjDuW5nLCBUaMOgbmggcGjhu5EgVGjDoWkgTmd1ecOqbiwgVGjDoWkgTmd1ecOqbiwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1637998932085!5m2!1svi!2s\" width=\"100%\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>', NULL, 'text', 7, 'Site'),
(13, 'site.phone', 'Điện thoại', '0947206728', NULL, 'text', 8, 'Site'),
(14, 'site.email', 'Email', 'biomartvietnam@gmail.com', NULL, 'text', 9, 'Site'),
(15, 'site.fax', 'Fax', '12885452', NULL, 'text', 10, 'Site'),
(16, 'site.address', 'Address', 'Số 167i - Đường Minh Cầu - Phường Phan Đình Phùng - Thành Phố Thái Nguyên', NULL, 'text', 11, 'Site'),
(17, 'site.website', 'Website', 'bio-organic.com.vn', NULL, 'text', 12, 'Site'),
(18, 'site.favicon', 'Favicon', 'settings/November2021/LMeVPrd49OUEuo36Vd0e.png', NULL, 'image', 13, 'Site'),
(19, 'social-network.facebook', 'Facebook', 'https://www.facebook.com/thainguyen.biomart', NULL, 'text', 14, 'social network'),
(20, 'social-network.gmail', 'Gmail', NULL, NULL, 'text', 15, 'social network'),
(21, 'social-network.youtube', 'Youtube', NULL, NULL, 'text', 16, 'social network'),
(22, 'social-network.twitter', 'twitter', NULL, NULL, 'text', 17, 'social network');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `staticdatas`
--

CREATE TABLE `staticdatas` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `staticdatas`
--

INSERT INTO `staticdatas` (`id`, `title`, `slug`, `description`, `body`, `image`, `meta_description`, `meta_keywords`, `type`, `status`, `created_at`, `updated_at`, `url`) VALUES
(1, 'Bio mart', 'bio-mart', 'Bio mart', '<p>Bio mart</p>', 'staticdatas/November2021/Fff9dtGBlBef0TZt0zZ0.jpg', NULL, NULL, 'linh-vuc-hoat-dong', 'ACTIVE', '2021-10-07 01:01:00', '2021-11-28 19:01:54', 'bio-mart'),
(2, 'Bicosoy', 'bicosoy', 'Bicosoy', '<p>Bicosoy</p>', 'staticdatas/November2021/IyJqL5kJwGHa7OfTJGFM.jpg', NULL, NULL, 'linh-vuc-hoat-dong', 'ACTIVE', '2021-10-07 01:07:00', '2021-11-28 19:01:36', 'bicosoy'),
(3, 'Bio Farm', 'bio-farm', 'Bio Farm', '<p>Bio Farm</p>', 'staticdatas/November2021/iEbvQC6oUNrpIcenEte4.jpg', NULL, NULL, 'linh-vuc-hoat-dong', 'ACTIVE', '2021-10-07 01:08:00', '2021-11-28 19:00:41', 'bio-fram'),
(4, 'Bio Mart', 'bio-mart-thuc-pham', 'Nơi bán những sản phẩm tiêu dùng cho gia đinh, phụ giúp các chị em nội trợ có bữa thật là an toàn và ngon, bổ, rẻ.', '<p>Nơi b&aacute;n những sản phẩm ti&ecirc;u d&ugrave;ng cho gia đinh, phụ gi&uacute;p c&aacute;c chị em nội trợ c&oacute; bữa thật l&agrave; an to&agrave;n v&agrave; ngon, bổ, rẻ.&nbsp;</p>', 'staticdatas/November2021/qgKUBbjZeMFSglC3LGhX.png', 'Bio Mart', 'Bio Mart', 'slide-website', 'ACTIVE', '2021-11-10 02:06:00', '2021-11-26 02:09:40', 'https://biomart.vn/'),
(5, 'Đặc Sản', 'dac-san', 'Nơi bán những sản phẩm tiêu dùng cho gia đinh, phụ giúp các chị em nội trợ có bữa thật là an toàn và ngon, bổ, rẻ.', '<p>Nơi b&aacute;n những sản phẩm ti&ecirc;u d&ugrave;ng cho gia đinh, phụ gi&uacute;p c&aacute;c chị em nội trợ c&oacute; bữa thật l&agrave; an to&agrave;n v&agrave; ngon, bổ, rẻ.</p>', 'staticdatas/November2021/tVC82E5beG6vJiRAeSSU.png', 'Đặc Sản', 'Đặc Sản', 'slide-website', 'ACTIVE', '2021-11-10 03:01:00', '2021-11-26 02:09:31', 'https://dacsanthainguyen.com.vn/'),
(6, 'Bio Organic', 'bio-organic', 'Nơi bán những sản phẩm tiêu dùng cho gia đinh, phụ giúp các chị em nội trợ có bữa thật là an toàn và ngon, bổ, rẻ.', '<p>Nơi b&aacute;n những sản phẩm ti&ecirc;u d&ugrave;ng cho gia đinh, phụ gi&uacute;p c&aacute;c chị em nội trợ c&oacute; bữa thật l&agrave; an to&agrave;n v&agrave; ngon, bổ, rẻ.</p>', 'staticdatas/November2021/mHhOEWsbqurnWnPNtwsQ.png', 'Bio Organic', 'Bio Organic', 'slide-website', 'ACTIVE', '2021-11-10 03:01:00', '2021-11-26 02:09:23', 'https://bio-organic.com.vn/');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `translations`
--

CREATE TABLE `translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `translations`
--

INSERT INTO `translations` (`id`, `table_name`, `column_name`, `foreign_key`, `locale`, `value`, `created_at`, `updated_at`) VALUES
(1, 'data_types', 'display_name_singular', 5, 'pt', 'Post', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(2, 'data_types', 'display_name_singular', 6, 'pt', 'Página', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(3, 'data_types', 'display_name_singular', 1, 'pt', 'Utilizador', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(4, 'data_types', 'display_name_singular', 4, 'pt', 'Categoria', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(5, 'data_types', 'display_name_singular', 2, 'pt', 'Menu', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(6, 'data_types', 'display_name_singular', 3, 'pt', 'Função', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(7, 'data_types', 'display_name_plural', 5, 'pt', 'Posts', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(8, 'data_types', 'display_name_plural', 6, 'pt', 'Páginas', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(9, 'data_types', 'display_name_plural', 1, 'pt', 'Utilizadores', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(10, 'data_types', 'display_name_plural', 4, 'pt', 'Categorias', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(11, 'data_types', 'display_name_plural', 2, 'pt', 'Menus', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(12, 'data_types', 'display_name_plural', 3, 'pt', 'Funções', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(13, 'categories', 'slug', 1, 'pt', 'categoria-1', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(14, 'categories', 'name', 1, 'pt', 'Categoria 1', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(15, 'categories', 'slug', 2, 'pt', 'categoria-2', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(16, 'categories', 'name', 2, 'pt', 'Categoria 2', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(17, 'pages', 'title', 1, 'pt', 'Olá Mundo', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(18, 'pages', 'slug', 1, 'pt', 'ola-mundo', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(19, 'pages', 'body', 1, 'pt', '<p>Olá Mundo. Scallywag grog swab Cat o\'nine tails scuttle rigging hardtack cable nipper Yellow Jack. Handsomely spirits knave lad killick landlubber or just lubber deadlights chantey pinnace crack Jennys tea cup. Provost long clothes black spot Yellow Jack bilged on her anchor league lateen sail case shot lee tackle.</p>\r\n<p>Ballast spirits fluke topmast me quarterdeck schooner landlubber or just lubber gabion belaying pin. Pinnace stern galleon starboard warp carouser to go on account dance the hempen jig jolly boat measured fer yer chains. Man-of-war fire in the hole nipperkin handsomely doubloon barkadeer Brethren of the Coast gibbet driver squiffy.</p>', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(20, 'menu_items', 'title', 1, 'pt', 'Painel de Controle', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(21, 'menu_items', 'title', 2, 'pt', 'Media', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(22, 'menu_items', 'title', 12, 'pt', 'Publicações', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(23, 'menu_items', 'title', 3, 'pt', 'Utilizadores', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(24, 'menu_items', 'title', 11, 'pt', 'Categorias', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(25, 'menu_items', 'title', 13, 'pt', 'Páginas', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(26, 'menu_items', 'title', 4, 'pt', 'Funções', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(27, 'menu_items', 'title', 5, 'pt', 'Ferramentas', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(28, 'menu_items', 'title', 6, 'pt', 'Menus', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(29, 'menu_items', 'title', 7, 'pt', 'Base de dados', '2021-10-05 20:45:14', '2021-10-05 20:45:14'),
(30, 'menu_items', 'title', 10, 'pt', 'Configurações', '2021-10-05 20:45:14', '2021-10-05 20:45:14');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `avatar`, `email_verified_at`, `password`, `remember_token`, `settings`, `created_at`, `updated_at`) VALUES
(1, 1, 'Admin', 'admin@admin.com', 'users/October2021/KBY0eask82qcHWA5cgu9.png', NULL, '$2y$10$4q/YseATIYhGrkDZI6oc9emrCq8TCXHkPzCJnXN/9jSodk3yfFzBa', 'HDJh8KaoOjbCP3WcyNWOD8uJKOm0B8yElibGLxoCgzf0dmdgGU8gcl8AvWL2', '{\"locale\":\"vi\"}', '2021-10-05 20:45:14', '2021-10-10 20:01:05');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user_roles`
--

CREATE TABLE `user_roles` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Chỉ mục cho bảng `data_rows`
--
ALTER TABLE `data_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_rows_data_type_id_foreign` (`data_type_id`);

--
-- Chỉ mục cho bảng `data_types`
--
ALTER TABLE `data_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_types_name_unique` (`name`),
  ADD UNIQUE KEY `data_types_slug_unique` (`slug`);

--
-- Chỉ mục cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Chỉ mục cho bảng `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_name_unique` (`name`);

--
-- Chỉ mục cho bảng `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_id_foreign` (`menu_id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`);

--
-- Chỉ mục cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Chỉ mục cho bảng `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissions_key_index` (`key`);

--
-- Chỉ mục cho bảng `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_permission_id_index` (`permission_id`),
  ADD KEY `permission_role_role_id_index` (`role_id`);

--
-- Chỉ mục cho bảng `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Chỉ mục cho bảng `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`);

--
-- Chỉ mục cho bảng `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Chỉ mục cho bảng `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

--
-- Chỉ mục cho bảng `staticdatas`
--
ALTER TABLE `staticdatas`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Chỉ mục cho bảng `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `user_roles_user_id_index` (`user_id`),
  ADD KEY `user_roles_role_id_index` (`role_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `data_rows`
--
ALTER TABLE `data_rows`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT cho bảng `data_types`
--
ALTER TABLE `data_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT cho bảng `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT cho bảng `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT cho bảng `staticdatas`
--
ALTER TABLE `staticdatas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `data_rows`
--
ALTER TABLE `data_rows`
  ADD CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Các ràng buộc cho bảng `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
